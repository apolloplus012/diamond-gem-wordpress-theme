import { Diamond, Heart, Mail, MapPin, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-diamond-dark text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
                <Diamond className="w-5 h-5 text-white animate-sparkle" />
              </div>
              <span className="text-xl font-bold">Diamond Darling</span>
            </div>
            <p className="text-blue-200 mb-4 text-sm leading-relaxed">
              Your trusted guide to finding the perfect lab-grown diamond with expert reviews and unbiased comparisons.
            </p>
            <div className="flex items-center gap-2 text-blue-200 text-sm">
              <Heart className="w-4 h-4 text-red-400" />
              <span>Made with love for diamond enthusiasts</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-blue-200">
              <li>
                <a href="#search" className="hover:text-white transition-colors">
                  Diamond Search
                </a>
              </li>
              <li>
                <a href="#compare" className="hover:text-white transition-colors">
                  Compare Diamonds
                </a>
              </li>
              <li>
                <a href="#education" className="hover:text-white transition-colors">
                  Diamond Education
                </a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-white transition-colors">
                  Expert Reviews
                </a>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h3 className="font-semibold mb-4">Resources</h3>
            <ul className="space-y-2 text-sm text-blue-200">
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  4C's Guide
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Certification Guide
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Price Trends
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-white transition-colors">
                  Buying Tips
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">Contact</h3>
            <div className="space-y-3 text-sm text-blue-200">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <span>hello@diamonddarling.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <span>1-800-DIAMOND</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>New York, NY</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-blue-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-sm text-blue-200">
            © 2024 Diamond Darling. All rights reserved.
          </div>
          <div className="flex gap-6 text-sm text-blue-200">
            <a href="#" className="hover:text-white transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Terms of Service
            </a>
            <a href="#" className="hover:text-white transition-colors">
              Affiliate Disclosure
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
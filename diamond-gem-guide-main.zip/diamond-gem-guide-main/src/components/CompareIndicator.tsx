import { useCompare } from "@/contexts/CompareContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { GitCompare } from "lucide-react";
import { useNavigate } from "react-router-dom";

const CompareIndicator = () => {
  const { comparedDiamonds } = useCompare();
  const navigate = useNavigate();

  if (comparedDiamonds.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Button
        onClick={() => navigate('/compare')}
        variant="premium"
        size="lg"
        className="shadow-premium"
      >
        <GitCompare className="w-4 h-4" />
        Compare
        <Badge variant="secondary" className="ml-2 bg-white text-primary">
          {comparedDiamonds.length}
        </Badge>
      </Button>
    </div>
  );
};

export default CompareIndicator;
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, TrendingUp, Shield, Users } from "lucide-react";

const features = [
  {
    icon: Search,
    title: "Advanced Search",
    description: "Filter by cut, color, clarity, and carat with real-time price comparisons across multiple retailers.",
    badge: "Smart Filters"
  },
  {
    icon: TrendingUp,
    title: "Price Tracking",
    description: "Monitor diamond prices and get alerts when your preferred stones drop in price.",
    badge: "Save Money"
  },
  {
    icon: Shield,
    title: "Certified Quality",
    description: "Every diamond comes with GIA or IGI certification ensuring authenticity and quality.",
    badge: "Verified"
  },
  {
    icon: Users,
    title: "Expert Reviews",
    description: "Read detailed reviews from diamond experts and real customers to make informed decisions.",
    badge: "Trusted"
  }
];

const FeatureSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4">
            Why Choose Us
          </Badge>
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Your Diamond Journey Made Simple
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            We combine cutting-edge technology with expert knowledge to help you find the perfect diamond at the best price.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={feature.title} 
              className="relative group hover:shadow-diamond transition-all duration-300 border-border/50 hover:border-primary/20"
            >
              <CardHeader className="text-center pb-4">
                <div className="relative mx-auto mb-4">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="w-8 h-8 text-primary group-hover:scale-110 transition-transform" />
                  </div>
                  <Badge 
                    variant="secondary" 
                    className="absolute -top-2 -right-2 text-xs bg-primary text-primary-foreground"
                  >
                    {feature.badge}
                  </Badge>
                </div>
                <CardTitle className="text-lg font-semibold">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-sm leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;
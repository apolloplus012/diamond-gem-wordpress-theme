import { Button } from "@/components/ui/button";
import { Diamond, Menu, Search } from "lucide-react";
import { useState } from "react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border/50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
              <Diamond className="w-5 h-5 text-white animate-sparkle" />
            </div>
            <span className="text-xl font-bold text-foreground">Diamond Darling</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="/search" className="text-muted-foreground hover:text-foreground transition-colors">
              Search Diamonds
            </a>
            <a href="/compare" className="text-muted-foreground hover:text-foreground transition-colors">
              Compare
            </a>
            <a href="/education" className="text-muted-foreground hover:text-foreground transition-colors">
              Education
            </a>
            <a href="/reviews" className="text-muted-foreground hover:text-foreground transition-colors">
              Reviews
            </a>
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-4">
            <Button variant="ghost" size="sm">
              <Search className="w-4 h-4" />
            </Button>
            <Button variant="default" size="sm">
              Get Started
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="w-5 h-5" />
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-border/50 py-4">
            <nav className="flex flex-col gap-4">
              <a href="/search" className="text-muted-foreground hover:text-foreground transition-colors py-2">
                Search Diamonds
              </a>
              <a href="/compare" className="text-muted-foreground hover:text-foreground transition-colors py-2">
                Compare
              </a>
              <a href="/education" className="text-muted-foreground hover:text-foreground transition-colors py-2">
                Education
              </a>
              <a href="/reviews" className="text-muted-foreground hover:text-foreground transition-colors py-2">
                Reviews
              </a>
              <div className="flex gap-4 pt-4 border-t border-border/50">
                <Button variant="ghost" size="sm" className="flex-1">
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Button>
                <Button variant="default" size="sm" className="flex-1">
                  Get Started
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
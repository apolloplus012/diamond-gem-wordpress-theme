import React from "react";
import { Star, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type ReviewQuoteProps = {
  text: string;
  vendor: string;
  author?: string;
  rating?: number; // 0-5
  date?: string | Date;
  verified?: boolean;
  maxChars?: number; // truncate length
  className?: string;
  dark?: boolean; // dark variant like reference image
};

/**
 * ReviewQuote
 * - Dark, compact quote block with stars, vendor, and optional Verified badge
 * - Truncates long quotes with an ellipsis
 * - Emits Review JSON-LD for SEO
 */
const ReviewQuote: React.FC<ReviewQuoteProps> = ({
  text,
  vendor,
  author,
  rating = 5,
  date,
  verified = true,
  maxChars = 140,
  className,
  dark = true,
}) => {
  const safeRating = Math.max(0, Math.min(5, Math.round(rating)));
  const truncated = text.length > maxChars;
  const displayText = truncated ? `${text.slice(0, maxChars).trimEnd()}…` : text;

  const { iso: dateISO, display: dateDisplay } = (() => {
    if (!date) return { iso: undefined as string | undefined, display: undefined as string | undefined };
    const d = new Date(date as any);
    if (isNaN(d.getTime())) {
      return { iso: undefined, display: typeof date === "string" ? date : undefined };
    }
    return { iso: d.toISOString(), display: d.toLocaleDateString() };
  })();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Review",
    reviewBody: text,
    author: { "@type": "Person", name: author || "Verified Reviewer" },
    itemReviewed: { "@type": "Organization", name: vendor },
    reviewRating: {
      "@type": "Rating",
      ratingValue: String(safeRating),
      bestRating: "5",
      worstRating: "1",
    },
    ...(dateISO ? { datePublished: dateISO } : {}),
  } as const;

  return (
    <figure
      className={cn(
        "relative overflow-hidden rounded-lg",
        // Dark variant surface using semantic tokens
        dark
          ? "bg-gradient-to-br from-background to-muted/70 ring-1 ring-border"
          : "bg-card ring-1 ring-border",
        "p-5 sm:p-6 shadow-sm",
        className
      )}
    >
      {/* Stars + Vendor + Verified */}
      <div className="mb-3 flex items-center gap-3">
        <div className="flex items-center">
          {Array.from({ length: 5 }).map((_, i) => (
            <Star
              key={i}
              aria-hidden
              className={cn(
                "h-4 w-4",
                i < safeRating ? "text-primary fill-primary" : "text-muted-foreground/50"
              )}
              strokeWidth={1.5}
            />
          ))}
          <span className="sr-only">Rated {safeRating} out of 5</span>
        </div>
        <span className="text-sm text-muted-foreground">{vendor}</span>
        {verified && (
          <Badge variant="secondary" className="inline-flex items-center gap-1">
            <ShieldCheck className="h-3.5 w-3.5" aria-hidden />
            Verified
          </Badge>
        )}
      </div>

      {/* Quote text */}
      <blockquote className="text-base sm:text-lg leading-relaxed">
        <span aria-hidden>“</span>
        {displayText}
        <span aria-hidden>”</span>
      </blockquote>

      {/* Attribution */}
      {(author || dateDisplay) && (
        <figcaption className="mt-3 text-sm text-muted-foreground">
          {author && <span>{author}</span>}
          {author && dateDisplay && <span> • </span>}
          {dateDisplay && (
            dateISO ? (
              <time dateTime={dateISO}>{dateDisplay}</time>
            ) : (
              <span>{dateDisplay}</span>
            )
          )}
        </figcaption>
      )}

      {/* Structured data for SEO */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
    </figure>
  );
};

export default ReviewQuote;

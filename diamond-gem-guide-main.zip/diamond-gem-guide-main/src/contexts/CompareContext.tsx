import { createContext, useContext, useState, ReactNode } from 'react';

export interface Diamond {
  id: number;
  shape: string;
  carat: number;
  color: string;
  clarity: string;
  cut: string;
  price: number;
  certification: string;
  image: string;
  vendor: string;
  rating: number;
}

interface CompareContextType {
  comparedDiamonds: Diamond[];
  addToCompare: (diamond: Diamond) => void;
  removeFromCompare: (diamondId: number) => void;
  clearCompare: () => void;
  isInCompare: (diamondId: number) => boolean;
}

const CompareContext = createContext<CompareContextType | undefined>(undefined);

export function CompareProvider({ children }: { children: ReactNode }) {
  const [comparedDiamonds, setComparedDiamonds] = useState<Diamond[]>([]);

  const addToCompare = (diamond: Diamond) => {
    setComparedDiamonds(prev => {
      if (prev.find(d => d.id === diamond.id)) return prev;
      if (prev.length >= 4) return prev; // Max 4 diamonds
      return [...prev, diamond];
    });
  };

  const removeFromCompare = (diamondId: number) => {
    setComparedDiamonds(prev => prev.filter(d => d.id !== diamondId));
  };

  const clearCompare = () => {
    setComparedDiamonds([]);
  };

  const isInCompare = (diamondId: number) => {
    return comparedDiamonds.some(d => d.id === diamondId);
  };

  return (
    <CompareContext.Provider value={{
      comparedDiamonds,
      addToCompare,
      removeFromCompare,
      clearCompare,
      isInCompare
    }}>
      {children}
    </CompareContext.Provider>
  );
}

export function useCompare() {
  const context = useContext(CompareContext);
  if (context === undefined) {
    throw new Error('useCompare must be used within a CompareProvider');
  }
  return context;
}
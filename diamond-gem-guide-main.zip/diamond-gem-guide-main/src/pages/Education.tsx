import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { BookOpen, Search, Clock, User, ArrowRight, Sparkles, Award, Shield } from "lucide-react";

const Education = () => {
  const featuredArticles = [
    {
      id: 1,
      title: "The Complete Guide to the 4Cs of Diamonds",
      excerpt: "Understanding Cut, Color, Clarity, and Carat weight - the foundation of diamond quality.",
      category: "Basics",
      readTime: "8 min read",
      author: "Sarah Mitchell",
      image: "/placeholder.svg",
      featured: true
    },
    {
      id: 2,
      title: "Lab-Grown vs Natural Diamonds: What's the Difference?",
      excerpt: "A comprehensive comparison of lab-grown and natural diamonds, including environmental and cost considerations.",
      category: "Buying Guide",
      readTime: "6 min read",
      author: "Dr. James Chen",
      image: "/placeholder.svg",
      featured: true
    },
    {
      id: 3,
      title: "Diamond Certification: GIA vs IGI vs Other Labs",
      excerpt: "Understanding different certification bodies and what their grades mean for your purchase.",
      category: "Certification",
      readTime: "5 min read",
      author: "Lisa Rodriguez",
      image: "/placeholder.svg",
      featured: false
    }
  ];

  const categories = [
    { name: "Diamond Basics", count: 24, icon: BookOpen, color: "bg-blue-500" },
    { name: "Buying Guides", count: 18, icon: Shield, color: "bg-green-500" },
    { name: "Certification", count: 12, icon: Award, color: "bg-purple-500" },
    { name: "Care & Maintenance", count: 8, icon: Sparkles, color: "bg-pink-500" }
  ];

  const recentArticles = [
    {
      title: "How to Clean Your Diamond Ring at Home",
      category: "Care & Maintenance",
      readTime: "4 min read",
      publishedAt: "2 days ago"
    },
    {
      title: "Understanding Diamond Fluorescence",
      category: "Diamond Basics",
      readTime: "6 min read",
      publishedAt: "5 days ago"
    },
    {
      title: "Best Diamond Shapes for Engagement Rings",
      category: "Buying Guide",
      readTime: "7 min read",
      publishedAt: "1 week ago"
    },
    {
      title: "Investment Value of Lab-Grown Diamonds",
      category: "Buying Guide",
      readTime: "9 min read",
      publishedAt: "1 week ago"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-hero">
          <div className="container mx-auto px-4 text-center">
            <BookOpen className="w-16 h-16 text-white mx-auto mb-6 animate-float" />
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Diamond Education Hub
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Your complete guide to understanding diamonds, from the basics to expert buying advice
            </p>
            
            {/* Search Bar */}
            <div className="max-w-md mx-auto relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input 
                placeholder="Search articles..." 
                className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/70"
              />
            </div>
          </div>
        </section>

        {/* Categories */}
        <section className="py-12 border-b border-border">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-8">Explore by Category</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {categories.map((category) => (
                <Card key={category.name} className="group hover:shadow-diamond transition-all duration-300 hover:scale-[1.02] cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className={`w-12 h-12 ${category.color} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                      <category.icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-semibold mb-2">{category.name}</h3>
                    <p className="text-muted-foreground text-sm">{category.count} articles</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Articles */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Featured Articles</h2>
            <div className="grid lg:grid-cols-2 gap-8 mb-12">
              {featuredArticles.filter(article => article.featured).map((article) => (
                <Card key={article.id} className="group hover:shadow-diamond transition-all duration-300 overflow-hidden">
                  <div className="aspect-video bg-gradient-sparkle"></div>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <Badge variant="secondary" className="bg-diamond-blue/10 text-diamond-blue">
                        {article.category}
                      </Badge>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="w-4 h-4" />
                        {article.readTime}
                      </div>
                    </div>
                    
                    <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors">
                      {article.title}
                    </h3>
                    <p className="text-muted-foreground mb-4">{article.excerpt}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{article.author}</span>
                      </div>
                      <Button variant="ghost" className="group-hover:text-primary">
                        Read More <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Recent Articles */}
        <section className="py-12 bg-muted/50">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <h2 className="text-3xl font-bold mb-8">Recent Articles</h2>
                <div className="space-y-6">
                  {recentArticles.map((article, index) => (
                    <Card key={index} className="p-6 hover:shadow-diamond transition-all duration-300 group cursor-pointer">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-4 mb-3">
                            <Badge variant="outline">{article.category}</Badge>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Clock className="w-4 h-4" />
                              {article.readTime}
                            </div>
                            <span className="text-sm text-muted-foreground">{article.publishedAt}</span>
                          </div>
                          <h3 className="text-lg font-semibold group-hover:text-primary transition-colors">
                            {article.title}
                          </h3>
                        </div>
                        <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                      </div>
                    </Card>
                  ))}
                </div>
                
                <div className="text-center mt-8">
                  <Button variant="outline" size="lg">
                    View All Articles
                  </Button>
                </div>
              </div>
              
              {/* Sidebar */}
              <div className="space-y-8">
                {/* Newsletter Signup */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Sparkles className="w-5 h-5" />
                      Stay Updated
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      Get the latest diamond education content and buying guides delivered to your inbox.
                    </p>
                    <Input placeholder="Enter your email" />
                    <Button variant="premium" className="w-full">
                      Subscribe
                    </Button>
                  </CardContent>
                </Card>
                
                {/* Quick Tips */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Tips</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="p-3 bg-muted rounded-lg">
                        <p className="text-sm font-medium">💎 Tip #1</p>
                        <p className="text-sm text-muted-foreground">Focus on cut quality - it affects brilliance more than any other factor.</p>
                      </div>
                      <div className="p-3 bg-muted rounded-lg">
                        <p className="text-sm font-medium">💎 Tip #2</p>
                        <p className="text-sm text-muted-foreground">Consider lab-grown diamonds for 30-40% savings with identical beauty.</p>
                      </div>
                      <div className="p-3 bg-muted rounded-lg">
                        <p className="text-sm font-medium">💎 Tip #3</p>
                        <p className="text-sm text-muted-foreground">GIA and IGI are the most trusted certification bodies worldwide.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Education;
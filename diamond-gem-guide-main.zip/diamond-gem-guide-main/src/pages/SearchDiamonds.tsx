import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCompare } from "@/contexts/CompareContext";
import { toast } from "sonner";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Search, Filter, Grid, List, Star, Heart, ExternalLink, Check } from "lucide-react";

const SearchDiamonds = () => {
  const { addToCompare, removeFromCompare, isInCompare, comparedDiamonds } = useCompare();
  const [viewMode, setViewMode] = useState("grid");
  const [priceRange, setPriceRange] = useState([1000, 50000]);
  const [caratRange, setCaratRange] = useState([0.5, 3.0]);
  const [selectedShape, setSelectedShape] = useState("");
  const [selectedCut, setSelectedCut] = useState("all");
  const [selectedClarity, setSelectedClarity] = useState("all");
  const [selectedColor, setSelectedColor] = useState("all");

  const handleAddToCompare = (diamond: any) => {
    if (isInCompare(diamond.id)) {
      removeFromCompare(diamond.id);
      toast.success("Removed from comparison");
    } else {
      if (comparedDiamonds.length >= 4) {
        toast.error("You can compare up to 4 diamonds only");
        return;
      }
      addToCompare(diamond);
      toast.success("Added to comparison");
    }
  };

  const shapes = [
    { name: "Round", value: "round" },
    { name: "Princess", value: "princess" },
    { name: "Emerald", value: "emerald" },
    { name: "Oval", value: "oval" },
    { name: "Marquise", value: "marquise" },
    { name: "Pear", value: "pear" },
    { name: "Cushion", value: "cushion" },
    { name: "Radiant", value: "radiant" },
    { name: "Asscher", value: "asscher" },
    { name: "Heart", value: "heart" },
    { name: "Trillion", value: "trillion" },
    { name: "Baguette", value: "baguette" },
    { name: "Rose Cut", value: "rose cut" },
    { name: "Old European", value: "old european" },
    { name: "Old Mine", value: "old mine" }
  ];
  const cuts = ["Excellent", "Very Good", "Good", "Fair", "Poor"];
  const clarities = ["FL", "IF", "VVS1", "VVS2", "VS1", "VS2", "SI1", "SI2", "SI3", "I1", "I2", "I3"];
  const colors = ["D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];

  const mockDiamonds = [
    {
      id: 1,
      shape: "Round",
      carat: 1.2,
      color: "G",
      clarity: "VS1",
      cut: "Excellent",
      price: 5850,
      certification: "GIA",
      image: "/placeholder.svg",
      vendor: "Rare Carat",
      rating: 4.8,
      depth: 61.8,
      table: 57,
      polish: "Excellent",
      symmetry: "Excellent",
      fluorescence: "None"
    },
    {
      id: 2,
      shape: "Princess",
      carat: 1.0,
      color: "F",
      clarity: "VVS2",
      cut: "Very Good",
      price: 4200,
      certification: "IGI",
      image: "/placeholder.svg",
      vendor: "Blue Nile",
      rating: 4.6,
      depth: 73.2,
      table: 71,
      polish: "Very Good",
      symmetry: "Very Good",
      fluorescence: "Faint"
    },
    {
      id: 3,
      shape: "Oval",
      carat: 1.5,
      color: "H",
      clarity: "SI1",
      cut: "Excellent",
      price: 6800,
      certification: "GIA",
      image: "/placeholder.svg",
      vendor: "James Allen",
      rating: 4.9,
      depth: 62.1,
      table: 58,
      polish: "Excellent",
      symmetry: "Excellent",
      fluorescence: "None"
    },
    {
      id: 4,
      shape: "Emerald",
      carat: 1.8,
      color: "E",
      clarity: "VVS1",
      cut: "Very Good",
      price: 8900,
      certification: "GIA",
      image: "/placeholder.svg",
      vendor: "Brilliant Earth",
      rating: 4.7,
      depth: 62.5,
      table: 64,
      polish: "Excellent",
      symmetry: "Very Good",
      fluorescence: "None"
    },
    {
      id: 5,
      shape: "Cushion",
      carat: 1.1,
      color: "I",
      clarity: "VS2",
      cut: "Good",
      price: 3950,
      certification: "IGI",
      image: "/placeholder.svg",
      vendor: "Costco",
      rating: 4.5,
      depth: 68.1,
      table: 62,
      polish: "Good",
      symmetry: "Good",
      fluorescence: "Medium"
    },
    {
      id: 6,
      shape: "Pear",
      carat: 1.3,
      color: "G",
      clarity: "SI2",
      cut: "Very Good",
      price: 5200,
      certification: "GIA",
      image: "/placeholder.svg",
      vendor: "Kay Jewelers",
      rating: 4.4,
      depth: 61.9,
      table: 59,
      polish: "Very Good",
      symmetry: "Good",
      fluorescence: "Faint"
    },
    {
      id: 7,
      shape: "Marquise",
      carat: 0.9,
      color: "D",
      clarity: "FL",
      cut: "Excellent",
      price: 7200,
      certification: "GIA",
      image: "/placeholder.svg",
      vendor: "Tiffany & Co",
      rating: 4.9,
      depth: 58.7,
      table: 55,
      polish: "Excellent",
      symmetry: "Excellent",
      fluorescence: "None"
    },
    {
      id: 8,
      shape: "Radiant",
      carat: 2.0,
      color: "J",
      clarity: "SI1",
      cut: "Good",
      price: 7800,
      certification: "IGI",
      image: "/placeholder.svg",
      vendor: "Zales",
      rating: 4.3,
      depth: 65.4,
      table: 67,
      polish: "Good",
      symmetry: "Good",
      fluorescence: "Strong"
    },
    {
      id: 9,
      shape: "Asscher",
      carat: 1.4,
      color: "F",
      clarity: "VVS2",
      cut: "Excellent",
      price: 6500,
      certification: "GIA",
      image: "/placeholder.svg",
      vendor: "Harry Winston",
      rating: 4.8,
      depth: 63.2,
      table: 61,
      polish: "Excellent",
      symmetry: "Excellent",
      fluorescence: "None"
    },
    {
      id: 10,
      shape: "Heart",
      carat: 1.0,
      color: "G",
      clarity: "VS1",
      cut: "Very Good",
      price: 4800,
      certification: "IGI",
      image: "/placeholder.svg",
      vendor: "Shane Co",
      rating: 4.6,
      depth: 59.8,
      table: 56,
      polish: "Very Good",
      symmetry: "Very Good",
      fluorescence: "None"
    },
    {
      id: 11,
      shape: "Round",
      carat: 2.5,
      color: "K",
      clarity: "I1",
      cut: "Fair",
      price: 9200,
      certification: "IGI",
      image: "/placeholder.svg",
      vendor: "Overstock",
      rating: 4.1,
      depth: 63.8,
      table: 59,
      polish: "Fair",
      symmetry: "Fair",
      fluorescence: "Strong"
    },
    {
      id: 12,
      shape: "Princess",
      carat: 0.8,
      color: "E",
      clarity: "IF",
      cut: "Excellent",
      price: 3800,
      certification: "GIA",
      image: "/placeholder.svg",
      vendor: "Whiteflash",
      rating: 4.9,
      depth: 75.1,
      table: 72,
      polish: "Excellent",
      symmetry: "Excellent",
      fluorescence: "None"
    }
  ];

  // Filter diamonds based on selected criteria
  const filteredDiamonds = mockDiamonds.filter((diamond) => {
    const matchesShape = !selectedShape || diamond.shape.toLowerCase() === selectedShape;
    const matchesCarat = diamond.carat >= caratRange[0] && diamond.carat <= caratRange[1];
    const matchesPrice = diamond.price >= priceRange[0] && diamond.price <= priceRange[1];
    const matchesCut = selectedCut === "all" || diamond.cut === selectedCut;
    const matchesClarity = selectedClarity === "all" || diamond.clarity === selectedClarity;
    const matchesColor = selectedColor === "all" || diamond.color === selectedColor;
    
    return matchesShape && matchesCarat && matchesPrice && matchesCut && matchesClarity && matchesColor;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-hero">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Find Your Perfect Diamond
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Search through thousands of certified lab-grown and natural diamonds with our advanced filtering system
            </p>
          </div>
        </section>

        {/* Search & Filters */}
        <section className="py-8 border-b border-border">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-4 gap-6">
              {/* Shape Filter */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-muted-foreground">Shape</label>
                <ToggleGroup type="single" value={selectedShape} onValueChange={setSelectedShape} className="grid grid-cols-4 gap-2">
                  {shapes.map((shape) => (
                    <ToggleGroupItem 
                      key={shape.value} 
                      value={shape.value} 
                      className="aspect-square flex flex-col items-center justify-center p-2"
                      title={shape.name}
                    >
                      <div className="w-6 h-6 bg-diamond-crystal border border-diamond-silver rounded-full mb-1"></div>
                      <span className="text-xs">{shape.name}</span>
                    </ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </div>

              {/* Carat Range */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-muted-foreground">
                  Carat ({caratRange[0]} - {caratRange[1]})
                </label>
                <Slider
                  value={caratRange}
                  onValueChange={setCaratRange}
                  max={5}
                  min={0.3}
                  step={0.1}
                  className="w-full"
                />
              </div>

              {/* Price Range */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-muted-foreground">
                  Price (${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()})
                </label>
                <Slider
                  value={priceRange}
                  onValueChange={setPriceRange}
                  max={100000}
                  min={500}
                  step={100}
                  className="w-full"
                />
              </div>

              {/* Quick Filters */}
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <Select value={selectedCut} onValueChange={setSelectedCut}>
                    <SelectTrigger>
                      <SelectValue placeholder="Cut" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Cuts</SelectItem>
                      {cuts.map((cut) => (
                        <SelectItem key={cut} value={cut}>{cut}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  <Select value={selectedClarity} onValueChange={setSelectedClarity}>
                    <SelectTrigger>
                      <SelectValue placeholder="Clarity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Clarity</SelectItem>
                      {clarities.map((clarity) => (
                        <SelectItem key={clarity} value={clarity}>{clarity}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Select value={selectedColor} onValueChange={setSelectedColor}>
                  <SelectTrigger>
                    <SelectValue placeholder="Color" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Colors</SelectItem>
                    {colors.map((color) => (
                      <SelectItem key={color} value={color}>{color}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </section>

        {/* Results Header */}
        <section className="py-6">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-semibold text-foreground">Search Results</h2>
                <p className="text-muted-foreground">Showing {filteredDiamonds.length} diamonds</p>
              </div>
              
              <div className="flex items-center gap-4">
                <Select defaultValue="price-low">
                  <SelectTrigger className="w-[140px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="carat-low">Carat: Low to High</SelectItem>
                    <SelectItem value="carat-high">Carat: High to Low</SelectItem>
                  </SelectContent>
                </Select>
                
                <ToggleGroup type="single" value={viewMode} onValueChange={setViewMode}>
                  <ToggleGroupItem value="grid">
                    <Grid className="w-4 h-4" />
                  </ToggleGroupItem>
                  <ToggleGroupItem value="list">
                    <List className="w-4 h-4" />
                  </ToggleGroupItem>
                </ToggleGroup>
              </div>
            </div>
          </div>
        </section>

        {/* Diamond Results */}
        <section className="pb-16">
          <div className="container mx-auto px-4">
            <div className={viewMode === "grid" ? "grid md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
              {filteredDiamonds.map((diamond) => (
                <Card key={diamond.id} className="group hover:shadow-diamond transition-all duration-300 hover:scale-[1.02]">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <Badge variant="secondary" className="bg-diamond-blue/10 text-diamond-blue">
                        {diamond.certification}
                      </Badge>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Heart className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="aspect-square bg-gradient-sparkle rounded-lg mb-4 flex items-center justify-center">
                      <div className="w-16 h-16 bg-diamond-crystal rounded-full animate-sparkle shadow-diamond"></div>
                    </div>
                    
                    <div className="space-y-2 mb-4">
                      <h3 className="font-semibold text-lg">{diamond.carat} Carat {diamond.shape}</h3>
                      <div className="grid grid-cols-3 gap-2 text-sm text-muted-foreground">
                        <div>Color: <span className="font-medium text-foreground">{diamond.color}</span></div>
                        <div>Clarity: <span className="font-medium text-foreground">{diamond.clarity}</span></div>
                        <div>Cut: <span className="font-medium text-foreground">{diamond.cut}</span></div>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center mb-4">
                      <div className="text-2xl font-bold text-primary">${diamond.price.toLocaleString()}</div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{diamond.rating}</span>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Button variant="premium" className="w-full">
                        View at {diamond.vendor}
                      </Button>
                      <Button 
                        variant={isInCompare(diamond.id) ? "default" : "outline"} 
                        className="w-full"
                        onClick={() => handleAddToCompare(diamond)}
                      >
                        {isInCompare(diamond.id) ? (
                          <>
                            <Check className="w-4 h-4 mr-2" />
                            Added to Compare
                          </>
                        ) : (
                          "Add to Compare"
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {/* Load More */}
            <div className="text-center mt-12">
              <Button variant="outline" size="lg">
                Load More Diamonds
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default SearchDiamonds;
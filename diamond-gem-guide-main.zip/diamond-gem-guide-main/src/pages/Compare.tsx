import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useCompare } from "@/contexts/CompareContext";
import { useNavigate } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Plus, X, Star, ExternalLink, ArrowLeftRight, Share2, Download } from "lucide-react";
import { toast } from "sonner";

const Compare = () => {
  const { comparedDiamonds, removeFromCompare } = useCompare();
  const navigate = useNavigate();

  const handleShareComparison = () => {
    const comparisonUrl = `${window.location.origin}/compare?diamonds=${comparedDiamonds.map(d => d.id).join(',')}`;
    navigator.clipboard.writeText(comparisonUrl);
    toast.success("Comparison link copied to clipboard!");
  };

  const handleExportPDF = () => {
    // In a real app, this would generate a PDF
    toast.success("PDF export feature coming soon!");
  };

  const comparisonSpecs = [
    { label: "Shape", key: "shape" },
    { label: "Carat", key: "carat" },
    { label: "Color", key: "color" },
    { label: "Clarity", key: "clarity" },
    { label: "Cut", key: "cut" },
    { label: "Price", key: "price", format: (value: number) => `$${value.toLocaleString()}` },
    { label: "Certification", key: "certification" },
    { label: "Depth %", key: "depth", format: (value: number) => `${value}%` },
    { label: "Table %", key: "table", format: (value: number) => `${value}%` },
    { label: "Polish", key: "polish" },
    { label: "Symmetry", key: "symmetry" },
    { label: "Fluorescence", key: "fluorescence" },
    { label: "Rating", key: "rating", format: (value: number) => `${value}/5` }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-hero">
          <div className="container mx-auto px-4 text-center">
            <ArrowLeftRight className="w-16 h-16 text-white mx-auto mb-6 animate-float" />
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Compare Diamonds
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Side-by-side comparison of diamond specifications to help you make the perfect choice
            </p>
          </div>
        </section>

        {comparedDiamonds.length === 0 ? (
          /* Empty State */
          <section className="py-16">
            <div className="container mx-auto px-4">
              <Card className="max-w-md mx-auto text-center">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-primary rounded-full mx-auto mb-6 flex items-center justify-center">
                    <Plus className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold mb-4">Start Your Comparison</h3>
                  <p className="text-muted-foreground mb-6">
                    Add diamonds from our search results to compare their specifications side by side.
                  </p>
                  <Button variant="premium" className="w-full" onClick={() => navigate('/search')}>
                    Search Diamonds
                  </Button>
                </CardContent>
              </Card>
            </div>
          </section>
        ) : (
          /* Comparison View */
          <section className="py-8">
            <div className="container mx-auto px-4">
              {/* Diamond Cards */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                {comparedDiamonds.map((diamond) => (
                  <Card key={diamond.id} className="relative group">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2 h-8 w-8 z-10 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => removeFromCompare(diamond.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                    
                    <CardContent className="p-6">
                      <Badge variant="secondary" className="bg-diamond-blue/10 text-diamond-blue mb-4">
                        {diamond.certification}
                      </Badge>
                      
                      <div className="aspect-square bg-gradient-sparkle rounded-lg mb-4 flex items-center justify-center">
                        <div className="w-16 h-16 bg-diamond-crystal rounded-full animate-sparkle shadow-diamond"></div>
                      </div>
                      
                      <h3 className="font-semibold text-lg mb-2">{diamond.carat} Carat {diamond.shape}</h3>
                      <div className="text-2xl font-bold text-primary mb-4">${diamond.price.toLocaleString()}</div>
                      
                      <div className="flex items-center gap-1 mb-4">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{diamond.rating}</span>
                        <span className="text-xs text-muted-foreground ml-1">({diamond.vendor})</span>
                      </div>
                      
                      <Button variant="premium" className="w-full">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View Details
                      </Button>
                    </CardContent>
                  </Card>
                ))}
                
                {/* Add More Button */}
                {comparedDiamonds.length < 4 && (
                  <Card className="border-dashed border-2 border-border hover:border-primary transition-colors group cursor-pointer">
                    <CardContent className="p-6 h-full flex flex-col items-center justify-center text-center">
                      <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors">
                        <Plus className="w-8 h-8 text-muted-foreground group-hover:text-primary" />
                      </div>
                      <h3 className="font-medium mb-2">Add Diamond</h3>
                      <p className="text-sm text-muted-foreground">Compare up to 4 diamonds</p>
                      <Button variant="ghost" size="sm" className="mt-2" onClick={() => navigate('/search')}>
                        Browse Diamonds
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
              
              {/* Comparison Table */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ArrowLeftRight className="w-5 h-5" />
                    Detailed Comparison
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr>
                          <th className="text-left py-3 px-4 font-medium text-muted-foreground">Specification</th>
                          {comparedDiamonds.map((diamond) => (
                            <th key={diamond.id} className="text-center py-3 px-4">
                              <div className="font-semibold">{diamond.shape} #{diamond.id}</div>
                              <div className="text-sm text-muted-foreground">{diamond.carat} Carat</div>
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {comparisonSpecs.map((spec) => (
                          <tr key={spec.key} className="border-t">
                            <td className="py-3 px-4 font-medium">{spec.label}</td>
                            {comparedDiamonds.map((diamond) => {
                              const value = diamond[spec.key as keyof typeof diamond];
                              const displayValue = spec.format ? spec.format(value as number) : value;
                              return (
                                <td key={diamond.id} className="text-center py-3 px-4">
                                  {displayValue}
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
              
              {/* Action Buttons */}
              <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
                <Button variant="premium" size="lg">
                  Get Price Alerts
                </Button>
                <Button variant="outline" size="lg" onClick={handleShareComparison}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Comparison
                </Button>
                <Button variant="outline" size="lg" onClick={handleExportPDF}>
                  <Download className="w-4 h-4 mr-2" />
                  Export to PDF
                </Button>
              </div>
            </div>
          </section>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Compare;
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Star, ExternalLink, Award, Shield, Truck, CreditCard, MessageCircle } from "lucide-react";
import ReviewQuote from "@/components/ReviewQuote";
import { useEffect } from "react";

const Reviews = () => {
  const vendors = [
    {
      id: 1,
      name: "Rare Carat",
      logo: "/placeholder.svg",
      rating: 4.8,
      totalReviews: 12847,
      description: "AI-powered diamond search with the largest inventory from trusted vendors.",
      pros: ["Best price comparison", "AI recommendations", "Large inventory", "Educational content"],
      cons: ["Limited physical locations", "No in-house manufacturing"],
      categories: {
        pricing: 4.9,
        selection: 4.8,
        service: 4.7,
        shipping: 4.6,
        quality: 4.8
      },
      features: ["Free shipping", "30-day returns", "GIA certified", "Price match"],
      affiliate: true,
      featured: true
    },
    {
      id: 2,
      name: "Blue Nile",
      logo: "/placeholder.svg",
      rating: 4.6,
      totalReviews: 8921,
      description: "Pioneer in online diamond sales with extensive customization options.",
      pros: ["Established reputation", "Custom settings", "Good customer service", "Virtual appointments"],
      cons: ["Higher prices", "Limited lab-grown selection"],
      categories: {
        pricing: 4.2,
        selection: 4.7,
        service: 4.8,
        shipping: 4.5,
        quality: 4.9
      },
      features: ["Free shipping", "30-day returns", "Custom settings", "Virtual consultations"],
      affiliate: true,
      featured: true
    },
    {
      id: 3,
      name: "James Allen",
      logo: "/placeholder.svg",
      rating: 4.7,
      totalReviews: 6543,
      description: "360-degree diamond viewing technology with extensive ring customization.",
      pros: ["360° diamond videos", "Custom rings", "Good photography", "Ring try-on"],
      cons: ["Premium pricing", "Limited lab-grown options"],
      categories: {
        pricing: 4.3,
        selection: 4.6,
        service: 4.7,
        shipping: 4.8,
        quality: 4.9
      },
      features: ["360° videos", "Free shipping", "Lifetime warranty", "Ring sizing"],
      affiliate: true,
      featured: true
    },
    {
      id: 4,
      name: "Brilliant Earth",
      logo: "/placeholder.svg",
      rating: 4.4,
      totalReviews: 4321,
      description: "Ethical and sustainable diamond sourcing with modern designs.",
      pros: ["Ethical sourcing", "Unique designs", "Lab-grown focus", "Showrooms"],
      cons: ["Higher prices", "Limited traditional options"],
      categories: {
        pricing: 4.1,
        selection: 4.5,
        service: 4.6,
        shipping: 4.3,
        quality: 4.7
      },
      features: ["Ethical sourcing", "Lab-grown focus", "Showrooms", "Custom design"],
      affiliate: true,
      featured: false
    },
    {
      id: 5,
      name: "Whiteflash",
      logo: "/placeholder.svg",
      rating: 4.7,
      totalReviews: 3789,
      description: "Known for super-ideal cut diamonds and exceptional craftsmanship.",
      pros: ["Super ideal cuts", "Great customer support", "Quality settings", "Fast shipping"],
      cons: ["Premium pricing", "Smaller selection"],
      categories: {
        pricing: 4.2,
        selection: 4.3,
        service: 4.8,
        shipping: 4.7,
        quality: 4.9
      },
      features: ["Super ideal", "Lifetime warranty", "Upgrade program", "Insured shipping"],
      affiliate: false,
      featured: true
    },
    {
      id: 6,
      name: "Ritani",
      logo: "/placeholder.svg",
      rating: 4.5,
      totalReviews: 5210,
      description: "Strong value with transparent pricing and in-store preview options.",
      pros: ["Transparent pricing", "In-store preview", "Good selection", "Financing"],
      cons: ["Website UX varies", "Limited 360 on some stones"],
      categories: {
        pricing: 4.5,
        selection: 4.5,
        service: 4.6,
        shipping: 4.4,
        quality: 4.6
      },
      features: ["In-store preview", "Free returns", "Transparent pricing", "Lifetime care"],
      affiliate: true,
      featured: true
    },
    {
      id: 7,
      name: "Clean Origin",
      logo: "/placeholder.svg",
      rating: 4.3,
      totalReviews: 2841,
      description: "Popular choice for lab-grown diamonds with competitive pricing.",
      pros: ["Lab-grown focus", "Competitive pricing", "Good selection", "Eco-conscious"],
      cons: ["Fewer natural options", "Limited showroom availability"],
      categories: {
        pricing: 4.6,
        selection: 4.2,
        service: 4.4,
        shipping: 4.3,
        quality: 4.5
      },
      features: ["Lab-grown", "Free resizing", "30-day returns", "Financing"],
      affiliate: false,
      featured: false
    },
    {
      id: 8,
      name: "With Clarity",
      logo: "/placeholder.svg",
      rating: 4.4,
      totalReviews: 1998,
      description: "Home try-on and 3D printed ring replicas for confident decisions.",
      pros: ["Home try-on", "3D replicas", "Custom designs", "Supportive consultants"],
      cons: ["Smaller inventory", "Shipping times vary"],
      categories: {
        pricing: 4.4,
        selection: 4.1,
        service: 4.5,
        shipping: 4.2,
        quality: 4.6
      },
      features: ["Home preview", "Free shipping", "Custom rings", "30-day returns"],
      affiliate: true,
      featured: false
    }
  ];

  const recentReviews = [
    {
      vendor: "Rare Carat",
      rating: 5,
      author: "Sarah M.",
      date: "2 days ago",
      review: "Amazing experience! Found the perfect diamond at 15% less than other sites. The AI recommendations were spot-on.",
      verified: true
    },
    {
      vendor: "Blue Nile",
      rating: 4,
      author: "Michael R.",
      date: "1 week ago",
      review: "Great quality diamond and excellent customer service. Shipping was fast and secure packaging.",
      verified: true
    },
    {
      vendor: "James Allen",
      rating: 5,
      author: "Emily C.",
      date: "2 weeks ago",
      review: "The 360° videos made me confident in my purchase. Beautiful ring and perfect customization options.",
      verified: true
    },
    {
      vendor: "Whiteflash",
      rating: 5,
      author: "Daniel K.",
      date: "3 weeks ago",
      review: "The cut quality is outstanding. The sparkle is next level and customer service was superb.",
      verified: true
    },
    {
      vendor: "Ritani",
      rating: 4,
      author: "Priya S.",
      date: "1 month ago",
      review: "Loved the in-store preview. The ring looked exactly as expected when it arrived.",
      verified: true
    },
    {
      vendor: "Clean Origin",
      rating: 4,
      author: "Alex P.",
      date: "1 month ago",
      review: "Great prices on lab-grown diamonds. Very happy with the purchase and fast shipping.",
      verified: true
    }
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i} 
        className={`w-4 h-4 ${i < Math.floor(rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} 
      />
    ));
  };

  const reviewsByVendor = Object.fromEntries(recentReviews.map((r) => [r.vendor, r]));

  // SEO
  useEffect(() => {
    document.title = "Diamond Vendor Reviews & Top Rated Vendors";
    const metaDescription = "Compare top-rated diamond vendors, see complete comparison and recent customer reviews.";
    let desc = document.querySelector('meta[name="description"]') as HTMLMetaElement | null;
    if (!desc) {
      desc = document.createElement('meta');
      desc.name = 'description';
      document.head.appendChild(desc);
    }
    desc.content = metaDescription;

    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = window.location.origin + "/reviews";
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-16 bg-gradient-hero">
          <div className="container mx-auto px-4 text-center">
            <Award className="w-16 h-16 text-white mx-auto mb-6 animate-float" />
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Vendor Reviews & Ratings
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Unbiased reviews and ratings of the top diamond retailers to help you choose with confidence
            </p>
          </div>
        </section>

        {/* Featured Vendors */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Top Rated Vendors</h2>
            
            <div className="grid lg:grid-cols-2 gap-8 mb-12">
              {vendors.filter(vendor => vendor.featured).map((vendor) => (
                <Card key={vendor.id} className="hover:shadow-diamond transition-all duration-300 group">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-xl">{vendor.name[0]}</span>
                        </div>
                        <div>
                          <CardTitle className="text-xl">{vendor.name}</CardTitle>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex">{renderStars(vendor.rating)}</div>
                            <span className="font-semibold">{vendor.rating}</span>
                            <span className="text-sm text-muted-foreground">
                              ({vendor.totalReviews.toLocaleString()} reviews)
                            </span>
                          </div>
                        </div>
                      </div>
                      {vendor.affiliate && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Partner
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-6">
                    <p className="text-muted-foreground">{vendor.description}</p>

                    <ReviewQuote
                      text={reviewsByVendor[vendor.name]?.review || vendor.description}
                      vendor={vendor.name}
                      author={reviewsByVendor[vendor.name]?.author}
                      rating={reviewsByVendor[vendor.name]?.rating || Math.round(vendor.rating)}
                      date={reviewsByVendor[vendor.name]?.date}
                      verified={reviewsByVendor[vendor.name]?.verified ?? true}
                      maxChars={120}
                      dark
                    />
                    
                    {/* Rating Breakdown */}
                    <div className="space-y-3">
                      <h4 className="font-semibold">Rating Breakdown</h4>
                      {Object.entries(vendor.categories).map(([category, rating]) => (
                        <div key={category} className="flex items-center gap-3">
                          <span className="w-20 text-sm capitalize">{category}</span>
                          <Progress value={rating * 20} className="flex-1" />
                          <span className="text-sm font-medium w-8">{rating}</span>
                        </div>
                      ))}
                    </div>
                    
                    {/* Pros & Cons */}
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h5 className="font-medium text-green-600 mb-2">Pros</h5>
                        <ul className="text-sm space-y-1">
                          {vendor.pros.map((pro, index) => (
                            <li key={index} className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                              {pro}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <h5 className="font-medium text-orange-600 mb-2">Cons</h5>
                        <ul className="text-sm space-y-1">
                          {vendor.cons.map((con, index) => (
                            <li key={index} className="flex items-center gap-2">
                              <div className="w-1.5 h-1.5 bg-orange-500 rounded-full"></div>
                              {con}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    
                    {/* Features */}
                    <div>
                      <h5 className="font-medium mb-2">Key Features</h5>
                      <div className="flex flex-wrap gap-2">
                        {vendor.features.map((feature, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex gap-3">
                      <Button variant="premium" className="flex-1">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Visit {vendor.name}
                      </Button>
                      <Button variant="outline" className="flex-1">
                        Full Review
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* All Vendors Comparison */}
        <section className="py-12 bg-muted/50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Complete Vendor Comparison</h2>
            
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-4 font-semibold">Vendor</th>
                        <th className="text-center p-4 font-semibold">Rating</th>
                        <th className="text-center p-4 font-semibold">Reviews</th>
                        <th className="text-center p-4 font-semibold">Pricing</th>
                        <th className="text-center p-4 font-semibold">Selection</th>
                        <th className="text-center p-4 font-semibold">Service</th>
                        <th className="text-center p-4 font-semibold">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {vendors.map((vendor) => (
                        <tr key={vendor.id} className="border-b hover:bg-muted/50">
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-gradient-primary rounded-full flex items-center justify-center">
                                <span className="text-white font-bold">{vendor.name[0]}</span>
                              </div>
                              <div>
                                <div className="font-semibold">{vendor.name}</div>
                                {vendor.affiliate && (
                                  <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                                    Partner
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="text-center p-4">
                            <div className="flex items-center justify-center gap-1">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span className="font-semibold">{vendor.rating}</span>
                            </div>
                          </td>
                          <td className="text-center p-4 text-sm text-muted-foreground">
                            {vendor.totalReviews.toLocaleString()}
                          </td>
                          <td className="text-center p-4">
                            <div className="flex justify-center">
                              {renderStars(vendor.categories.pricing)}
                            </div>
                          </td>
                          <td className="text-center p-4">
                            <div className="flex justify-center">
                              {renderStars(vendor.categories.selection)}
                            </div>
                          </td>
                          <td className="text-center p-4">
                            <div className="flex justify-center">
                              {renderStars(vendor.categories.service)}
                            </div>
                          </td>
                          <td className="text-center p-4">
                            <Button variant="outline" size="sm">
                              Visit Site
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Recent Reviews */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Recent Customer Reviews</h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentReviews.map((review, index) => (
                <Card key={index} className="hover:shadow-diamond transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <div className="flex">{renderStars(review.rating)}</div>
                        {review.verified && (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            <Shield className="w-3 h-3 mr-1" />
                            Verified
                          </Badge>
                        )}
                      </div>
                      <span className="text-sm text-muted-foreground">{review.date}</span>
                    </div>
                    
                    <p className="text-sm mb-4">"{review.review}"</p>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-sm">{review.author}</div>
                        <div className="text-xs text-muted-foreground">{review.vendor}</div>
                      </div>
                      <Button variant="ghost" size="icon">
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            <div className="text-center mt-8">
              <Button variant="outline" size="lg">
                View All Reviews
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Reviews;
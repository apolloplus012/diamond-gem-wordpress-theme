<?php
/**
 * The header for the Diamonds Theme.
 *
 * Displays all of the <head> section and everything up until the <main> tag.
 *
 * @package Diamonds Theme
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<header class="site-header">
    <div class="header-inner">
        <div class="site-branding">
            <?php if ( has_custom_logo() ) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-title">
                    <?php bloginfo( 'name' ); ?>
                </a>
            <?php endif; ?>
        </div><!-- .site-branding -->
        <nav class="primary-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'diamonds-theme' ); ?>">
            <?php
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'menu_class'     => 'primary-menu',
                'container'      => false,
                'fallback_cb'    => false,
            ) );
            ?>
        </nav><!-- .primary-navigation -->
    </div><!-- .header-inner -->
</header><!-- .site-header -->
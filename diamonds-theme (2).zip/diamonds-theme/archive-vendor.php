<?php
/**
 * The template for displaying the vendor archive page.
 *
 * This template renders a hero section with a heading and tagline,
 * followed by a list of vendor cards, a comparison table and a grid of
 * recent customer reviews. It leverages helper functions defined in
 * functions.php to render individual vendor cards and table rows.
 *
 * @package Diamonds Theme
 */

get_header();
?>

<main id="primary" class="site-main vendor-archive">
    <section class="vendor-hero">
        <h1><?php esc_html_e( 'Vendor Reviews & Ratings', 'diamonds-theme' ); ?></h1>
        <p class="vendor-hero-tagline">
            <?php esc_html_e( 'Unbiased reviews and ratings of the top diamond retailers to help you choose with confidence', 'diamonds-theme' ); ?>
        </p>
    </section>

    <section class="vendor-listing">
        <h2><?php esc_html_e( 'Top Rated Vendors', 'diamonds-theme' ); ?></h2>
        <?php
        // Query published vendors, ordered by overall rating descending.
        $vendor_query = new WP_Query( array(
            'post_type'      => 'vendor',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_key'       => '_vd_rating',
            'orderby'        => 'meta_value_num',
            'order'          => 'DESC',
        ) );
        if ( $vendor_query->have_posts() ) :
            echo '<div class="vendor-cards">';
            while ( $vendor_query->have_posts() ) :
                $vendor_query->the_post();
                echo diamonds_get_vendor_card( get_the_ID() );
            endwhile;
            echo '</div>';
            wp_reset_postdata();
        else :
            echo '<p>' . esc_html__( 'No vendors found.', 'diamonds-theme' ) . '</p>';
        endif;
        ?>
    </section>

    <section class="vendor-comparison-section">
        <h2><?php esc_html_e( 'Complete Vendor Comparison', 'diamonds-theme' ); ?></h2>
        <?php
        // Reuse the vendor query for the comparison table.
        $vendors_table_query = new WP_Query( array(
            'post_type'      => 'vendor',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_key'       => '_vd_rating',
            'orderby'        => 'meta_value_num',
            'order'          => 'DESC',
        ) );
        if ( $vendors_table_query->have_posts() ) :
            echo '<table class="vendor-comparison-table">';
            echo '<thead><tr>';
            echo '<th>' . esc_html__( 'Vendor', 'diamonds-theme' ) . '</th>';
            echo '<th>' . esc_html__( 'Rating', 'diamonds-theme' ) . '</th>';
            echo '<th>' . esc_html__( 'Reviews', 'diamonds-theme' ) . '</th>';
            echo '<th>' . esc_html__( 'Pricing', 'diamonds-theme' ) . '</th>';
            echo '<th>' . esc_html__( 'Selection', 'diamonds-theme' ) . '</th>';
            echo '<th>' . esc_html__( 'Service', 'diamonds-theme' ) . '</th>';
            echo '<th>' . esc_html__( 'Action', 'diamonds-theme' ) . '</th>';
            echo '</tr></thead>';
            echo '<tbody>';
            while ( $vendors_table_query->have_posts() ) :
                $vendors_table_query->the_post();
                echo diamonds_get_vendor_table_row( get_the_ID() );
            endwhile;
            echo '</tbody></table>';
            wp_reset_postdata();
        endif;
        ?>
    </section>

    <section class="recent-reviews-section">
        <h2><?php esc_html_e( 'Recent Customer Reviews', 'diamonds-theme' ); ?></h2>
        <?php echo diamonds_get_recent_reviews( 6 ); ?>
        <div class="reviews-actions">
            <a href="<?php echo esc_url( home_url( '/review/' ) ); ?>" class="button view-all-reviews">
                <?php esc_html_e( 'View All Reviews', 'diamonds-theme' ); ?>
            </a>
        </div>
    </section>

</main><!-- #primary -->

<?php
get_footer();
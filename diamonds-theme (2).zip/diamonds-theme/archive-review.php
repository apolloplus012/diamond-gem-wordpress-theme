<?php
/**
 * Archive template for customer reviews.
 *
 * Displays a list of all published customer reviews with ratings and
 * excerpts, along with pagination links. Reviews are ordered by date
 * descending. Each review links to its single view page.
 *
 * @package Diamonds Theme
 */

get_header();
?>

<main id="primary" class="site-main review-archive">
    <header class="page-header">
        <h1 class="page-title"><?php esc_html_e( 'Customer Reviews', 'diamonds-theme' ); ?></h1>
    </header>
    <?php if ( have_posts() ) : ?>
        <div class="reviews-grid">
            <?php while ( have_posts() ) : the_post();
                $rv_rating   = intval( get_post_meta( get_the_ID(), '_rv_rating', true ) );
                $rv_verified = filter_var( get_post_meta( get_the_ID(), '_rv_verified', true ), FILTER_VALIDATE_BOOLEAN );
                $vendor_id   = intval( get_post_meta( get_the_ID(), '_rv_vendor', true ) );
                $vendor_name = $vendor_id ? get_the_title( $vendor_id ) : '';
                ?>
                <article class="review-card">
                    <div class="review-rating">
                        <?php for ( $i = 0; $i < 5; $i++ ) {
                            echo ( $i < $rv_rating ) ? '★' : '☆';
                        } ?>
                        <?php if ( $rv_verified ) : ?><span class="review-verified"><?php esc_html_e( 'Verified', 'diamonds-theme' ); ?></span><?php endif; ?>
                        <span class="review-date"><?php echo esc_html( human_time_diff( get_the_date( 'U' ), current_time( 'timestamp' ) ) ); ?> <?php esc_html_e( 'ago', 'diamonds-theme' ); ?></span>
                    </div>
                    <h2 class="review-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="review-body">
                        <?php the_excerpt(); ?>
                    </div>
                    <div class="review-footer">
                        <span class="review-author"><?php the_author(); ?></span>
                        <?php if ( $vendor_name ) : ?>
                            <span class="review-vendor"><?php echo esc_html( $vendor_name ); ?></span>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>
        <?php the_posts_pagination(); ?>
    <?php else : ?>
        <?php get_template_part( 'template-parts/content', 'none' ); ?>
    <?php endif; ?>
</main>

<?php get_footer(); ?>
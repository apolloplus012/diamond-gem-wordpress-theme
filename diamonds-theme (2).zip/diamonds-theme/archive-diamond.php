<?php
/**
 * Template for the Diamond archive and search.
 *
 * This template displays a list of diamonds and a filter sidebar that
 * allows users to filter by taxonomy terms. Filters submit via AJAX
 * using the diamond-search.js script. Pagination falls back to standard
 * WP pagination when JavaScript is disabled.
 *
 * @package Diamonds Theme
 */

get_header();
?>
<main id="primary" class="site-main">
    <header class="page-header">
        <h1 class="page-title"><?php _e( 'Find Your Diamond', 'diamonds-theme' ); ?></h1>
    </header>

    <div class="diamonds-container">
        <?php
        // Output the search form and results via shortcode.
        echo do_shortcode( '[diamond_search]' );
        ?>
    </div>
</main>
<?php
get_footer();
<?php
/**
 * Template for displaying single vendor pages.
 *
 * Displays detailed information about a specific vendor including rating
 * breakdown, pros/cons, key features and customer reviews. This template
 * assumes that vendors have meta fields registered via functions.php.
 *
 * @package Diamonds Theme
 */

get_header();

while ( have_posts() ) :
    the_post();
    $vendor_id  = get_the_ID();
    $title      = get_the_title();
    $rating     = floatval( get_post_meta( $vendor_id, '_vd_rating', true ) );
    $reviews    = intval( get_post_meta( $vendor_id, '_vd_reviews', true ) );
    $pricing    = floatval( get_post_meta( $vendor_id, '_vd_pricing', true ) );
    $selection  = floatval( get_post_meta( $vendor_id, '_vd_selection', true ) );
    $service    = floatval( get_post_meta( $vendor_id, '_vd_service', true ) );
    $shipping   = floatval( get_post_meta( $vendor_id, '_vd_shipping', true ) );
    $quality    = floatval( get_post_meta( $vendor_id, '_vd_quality', true ) );
    $pros       = array_filter( array_map( 'trim', explode( ',', get_post_meta( $vendor_id, '_vd_pros', true ) ) ) );
    $cons       = array_filter( array_map( 'trim', explode( ',', get_post_meta( $vendor_id, '_vd_cons', true ) ) ) );
    $features   = get_the_terms( $vendor_id, 'vendor_feature' );
    $url        = esc_url( get_post_meta( $vendor_id, '_vd_url', true ) );
    $partner    = filter_var( get_post_meta( $vendor_id, '_vd_partner', true ), FILTER_VALIDATE_BOOLEAN );
    ?>
    <main id="primary" class="site-main single-vendor">
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
            <header class="vendor-single-header">
                <h1 class="vendor-single-title"><?php echo esc_html( $title ); ?></h1>
                <?php if ( $partner ) : ?><span class="vendor-partner-badge"><?php esc_html_e( 'Partner', 'diamonds-theme' ); ?></span><?php endif; ?>
                <div class="vendor-single-rating">
                    <span class="rating-stars">
                        <?php
                        $full = floor( $rating );
                        $half = ( $rating - $full ) >= 0.5;
                        for ( $i = 0; $i < 5; $i++ ) {
                            if ( $i < $full ) {
                                echo '★';
                            } elseif ( $i === $full && $half ) {
                                echo '☆';
                                $half = false;
                            } else {
                                echo '☆';
                            }
                        }
                        ?>
                    </span>
                    <span class="vendor-rating-value"><?php echo esc_html( number_format_i18n( $rating, 1 ) ); ?></span>
                    <?php if ( $reviews ) : ?>
                        <span class="vendor-review-count">(<?php echo esc_html( number_format_i18n( $reviews ) ); ?> <?php esc_html_e( 'reviews', 'diamonds-theme' ); ?>)</span>
                    <?php endif; ?>
                </div>
                <?php if ( $url ) : ?>
                    <p class="vendor-visit-link"><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="nofollow sponsored" class="button">
                        <?php printf( esc_html__( 'Visit %s', 'diamonds-theme' ), esc_html( $title ) ); ?></a></p>
                <?php endif; ?>
            </header>

            <div class="vendor-single-content">
                <?php the_content(); ?>
            </div>

            <section class="vendor-rating-breakdown">
                <h2><?php esc_html_e( 'Rating Breakdown', 'diamonds-theme' ); ?></h2>
                <div class="rating-bar-group">
                    <?php
                    $categories = array(
                        'Pricing'   => $pricing,
                        'Selection' => $selection,
                        'Service'   => $service,
                        'Shipping'  => $shipping,
                        'Quality'   => $quality,
                    );
                    foreach ( $categories as $label => $value ) :
                        $percent = $value ? min( 100, ( $value / 5 ) * 100 ) : 0;
                        ?>
                        <div class="rating-bar-item">
                            <span class="rating-label"><?php echo esc_html( $label ); ?></span>
                            <div class="rating-bar">
                                <div class="rating-bar-fill" style="width: <?php echo esc_attr( $percent ); ?>%;"></div>
                            </div>
                            <span class="rating-value"><?php echo esc_html( number_format_i18n( $value, 1 ) ); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <?php if ( ! empty( $pros ) || ! empty( $cons ) ) : ?>
                <section class="vendor-pros-cons-section">
                    <div class="vendor-pros-cons-container">
                        <?php if ( ! empty( $pros ) ) : ?>
                            <div class="vendor-pros">
                                <h3><?php esc_html_e( 'Pros', 'diamonds-theme' ); ?></h3>
                                <ul>
                                    <?php foreach ( $pros as $pro ) : ?>
                                        <li><?php echo esc_html( $pro ); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if ( ! empty( $cons ) ) : ?>
                            <div class="vendor-cons">
                                <h3><?php esc_html_e( 'Cons', 'diamonds-theme' ); ?></h3>
                                <ul>
                                    <?php foreach ( $cons as $con ) : ?>
                                        <li><?php echo esc_html( $con ); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ( $features && ! is_wp_error( $features ) ) : ?>
                <section class="vendor-features-section">
                    <h2><?php esc_html_e( 'Key Features', 'diamonds-theme' ); ?></h2>
                    <div class="vendor-feature-tags">
                        <?php foreach ( $features as $feature ) : ?>
                            <span class="vendor-feature-tag"><?php echo esc_html( $feature->name ); ?></span>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php
            // Query customer reviews associated with this vendor.
            $reviews_query = new WP_Query( array(
                'post_type'      => 'review',
                'post_status'    => 'publish',
                'posts_per_page' => 6,
                'meta_query'     => array(
                    array(
                        'key'   => '_rv_vendor',
                        'value' => $vendor_id,
                        'compare' => '=',
                    ),
                ),
                'orderby'        => 'date',
                'order'          => 'DESC',
            ) );
            if ( $reviews_query->have_posts() ) :
            ?>
                <section class="vendor-customer-reviews">
                    <h2><?php esc_html_e( 'Customer Reviews', 'diamonds-theme' ); ?></h2>
                    <div class="recent-reviews-grid">
                        <?php while ( $reviews_query->have_posts() ) : $reviews_query->the_post();
                            $rv_rating   = intval( get_post_meta( get_the_ID(), '_rv_rating', true ) );
                            $rv_verified = filter_var( get_post_meta( get_the_ID(), '_rv_verified', true ), FILTER_VALIDATE_BOOLEAN );
                            ?>
                            <div class="review-card">
                                <div class="review-rating">
                                    <?php for ( $i = 0; $i < 5; $i++ ) {
                                        echo ( $i < $rv_rating ) ? '★' : '☆';
                                    } ?>
                                    <?php if ( $rv_verified ) : ?><span class="review-verified"><?php esc_html_e( 'Verified', 'diamonds-theme' ); ?></span><?php endif; ?>
                                    <span class="review-date"><?php echo esc_html( human_time_diff( get_the_date( 'U' ), current_time( 'timestamp' ) ) ); ?> <?php esc_html_e( 'ago', 'diamonds-theme' ); ?></span>
                                </div>
                                <div class="review-body">
                                    <?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 25 ) ); ?>
                                </div>
                                <div class="review-footer">
                                    <span class="review-author"><?php echo esc_html( get_the_author() ); ?></span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </section>
            <?php
                wp_reset_postdata();
            endif;
            ?>
        </article>
    </main>
<?php
endwhile; // End of the loop.

get_footer();
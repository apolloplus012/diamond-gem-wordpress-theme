<?php
/**
 * The template for displaying a single Diamond post.
 *
 * Displays detailed information about a diamond, including images,
 * price breakdown and vendor information. A "Buy Now" button uses
 * the affiliate URL stored in post meta and is marked as sponsored
 * and nofollow for SEO compliance.
 *
 * @package Diamonds Theme
 */

get_header();
?>
<main id="primary" class="site-main">
    <?php
    while ( have_posts() ) :
        the_post();
        ?>
        <article <?php post_class(); ?>>
            <header class="entry-header">
                <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
            </header>
            <div class="entry-content">
                <?php
                // Display featured image or gallery.
                if ( has_post_thumbnail() ) {
                    echo '<div class="featured-image">';
                    the_post_thumbnail( 'large' );
                    echo '</div>';
                }

                // Display the main content (could be used for description or additional details).
                the_content();
                ?>
                <div class="diamond-meta" style="margin-top:1rem;">
                    <p><strong><?php _e( 'Carat:', 'diamonds-theme' ); ?></strong> <?php echo esc_html( get_post_meta( get_the_ID(), '_dd_carat', true ) ); ?>ct</p>
                    <p><strong><?php _e( 'Price:', 'diamonds-theme' ); ?></strong> <?php echo esc_html( number_format_i18n( get_post_meta( get_the_ID(), '_dd_price', true ), 2 ) ); ?></p>
                    <p><strong><?php _e( 'Vendor:', 'diamonds-theme' ); ?></strong> <?php echo esc_html( get_post_meta( get_the_ID(), '_dd_vendor', true ) ); ?></p>
                </div>
                <?php
                $affiliate_url = get_post_meta( get_the_ID(), '_dd_affiliate_url', true );
                if ( $affiliate_url ) :
                    ?>
                    <p><a href="<?php echo esc_url( $affiliate_url ); ?>" class="button" target="_blank" rel="sponsored nofollow"><?php _e( 'Buy Now', 'diamonds-theme' ); ?></a></p>
                    <?php
                endif;
                ?>
            </div>
        </article>
        <?php
    endwhile; // End of the loop.
    ?>
</main>
<?php
get_footer();
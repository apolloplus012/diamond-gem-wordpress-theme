<?php
/**
 * Template for displaying individual customer reviews.
 *
 * Shows the review title, rating, verification, vendor association, date
 * and full content. Includes navigation links back to the review archive.
 *
 * @package Diamonds Theme
 */

get_header();
?>

<main id="primary" class="site-main single-review">
    <?php
    while ( have_posts() ) :
        the_post();
        $rv_rating   = intval( get_post_meta( get_the_ID(), '_rv_rating', true ) );
        $rv_verified = filter_var( get_post_meta( get_the_ID(), '_rv_verified', true ), FILTER_VALIDATE_BOOLEAN );
        $vendor_id   = intval( get_post_meta( get_the_ID(), '_rv_vendor', true ) );
        $vendor_name = $vendor_id ? get_the_title( $vendor_id ) : '';
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
            <header class="entry-header">
                <h1 class="entry-title"><?php the_title(); ?></h1>
                <div class="review-meta">
                    <span class="review-rating">
                        <?php for ( $i = 0; $i < 5; $i++ ) {
                            echo ( $i < $rv_rating ) ? '★' : '☆';
                        } ?>
                    </span>
                    <?php if ( $rv_verified ) : ?><span class="review-verified"><?php esc_html_e( 'Verified', 'diamonds-theme' ); ?></span><?php endif; ?>
                    <span class="review-date"><?php echo esc_html( get_the_date() ); ?></span>
                    <?php if ( $vendor_name ) : ?>
                        <span class="review-vendor">
                            <?php
                            printf(
                                /* translators: %s: vendor name */
                                esc_html__( 'Vendor: %s', 'diamonds-theme' ),
                                esc_html( $vendor_name )
                            );
                            ?>
                        </span>
                    <?php endif; ?>
                </div>
            </header>
            <div class="entry-content">
                <?php the_content(); ?>
            </div>
        </article>
        <?php the_post_navigation( array(
            'prev_text' => __( '<span class="nav-subtitle">Previous:</span> <span class="nav-title">%title</span>', 'diamonds-theme' ),
            'next_text' => __( '<span class="nav-subtitle">Next:</span> <span class="nav-title">%title</span>', 'diamonds-theme' ),
        ) );
        break;
    endwhile; // End of the loop.
    ?>
</main>

<?php get_footer(); ?>
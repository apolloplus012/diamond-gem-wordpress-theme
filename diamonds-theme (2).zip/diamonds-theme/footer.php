<?php
/**
 * The footer for the Diamonds Theme.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Diamonds Theme
 */
?>

<footer class="site-footer">
    <div class="footer-inner">
        <div class="footer-widgets">
            <?php
            // Display footer menu if assigned.
            if ( has_nav_menu( 'footer' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'footer',
                    'menu_class'     => 'footer-menu',
                    'container'      => false,
                ) );
            }
            ?>
        </div>
        <div class="site-info">
            <?php
            /* translators: 1: current year, 2: site name */
            printf( esc_html__( '© %1$s %2$s. All rights reserved.', 'diamonds-theme' ), date_i18n( 'Y' ), get_bloginfo( 'name' ) );
            ?>
        </div>
    </div><!-- .footer-inner -->
</footer><!-- .site-footer -->

<?php wp_footer(); ?>
</body>
</html>
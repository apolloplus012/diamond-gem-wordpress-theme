<?php
/**
 * Diamonds Theme functions and definitions
 *
 * @package Diamonds Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

if ( ! function_exists( 'diamonds_theme_setup' ) ) :
/**
 * Theme setup function.
 *
 * Sets up theme defaults and registers support for various WordPress features.
 */
function diamonds_theme_setup() {
    // Make theme available for translation. Translations can be filed in the /languages/ directory.
    load_theme_textdomain( 'diamonds-theme', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    // Let WordPress manage the document title.
    add_theme_support( 'title-tag' );

    // Enable support for Post Thumbnails on posts and pages.
    add_theme_support( 'post-thumbnails' );

    // Switch default core markup for search form, comment form, comments, galleries and captions to output valid HTML5.
    add_theme_support( 'html5', array( 'search-form', 'comment-list', 'comment-form', 'gallery', 'caption', 'script', 'style' ) );

    // Support custom logo.
    add_theme_support( 'custom-logo', array(
        'height'      => 64,
        'width'       => 256,
        'flex-width'  => true,
        'flex-height' => true,
    ) );

    // Register primary and footer menus.
    register_nav_menus(
        array(
            'primary' => __( 'Primary Menu', 'diamonds-theme' ),
            'footer'  => __( 'Footer Menu', 'diamonds-theme' ),
        )
    );
}
endif;
add_action( 'after_setup_theme', 'diamonds_theme_setup' );

/**
 * Enqueue front-end scripts and styles for the Diamonds theme.
 *
 * Loads the main stylesheet, Google Fonts, and the diamond search JavaScript.
 * Also localizes the AJAX URL so the JS can make requests to admin-ajax.php.
 */
function diamonds_enqueue_scripts() {
    // Theme stylesheet with versioning based on file modification time.
    wp_enqueue_style(
        'diamonds-style',
        get_stylesheet_uri(),
        array(),
        filemtime( get_template_directory() . '/style.css' )
    );

    // Google Fonts: Inter and Playfair Display.
    wp_enqueue_style(
        'diamonds-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Playfair+Display:wght@400;700&display=swap',
        array(),
        null
    );

    // Main search script.
    wp_enqueue_script(
        'diamonds-search',
        get_template_directory_uri() . '/assets/js/diamond-search.js',
        array( 'jquery' ),
        filemtime( get_template_directory() . '/assets/js/diamond-search.js' ),
        true
    );

    // Localize the script with the AJAX URL.
    wp_localize_script(
        'diamonds-search',
        'diamondsSearch',
        array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        )
    );
}
add_action( 'wp_enqueue_scripts', 'diamonds_enqueue_scripts' );

/**
 * Enqueue scripts and styles.
 */
function diamonds_theme_scripts() {
    // Main stylesheet loaded from style.css.
    wp_enqueue_style( 'diamonds-theme-style', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );

    // Custom JavaScript file to handle the diamond search via AJAX.
    wp_enqueue_script( 'diamonds-search', get_template_directory_uri() . '/assets/js/diamond-search.js', array( 'jquery' ), wp_get_theme()->get( 'Version' ), true );

    // Pass data to the script: ajax URL and nonce for security.
    wp_localize_script(
        'diamonds-search',
        'diamondsSearch',
        array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'diamonds_search_nonce' ),
        )
    );
}
add_action( 'wp_enqueue_scripts', 'diamonds_theme_scripts' );

/**
 * Register the custom post type for Diamonds.
 */
function diamonds_register_cpt() {
    $labels = array(
        'name'               => _x( 'Diamonds', 'post type general name', 'diamonds-theme' ),
        'singular_name'      => _x( 'Diamond', 'post type singular name', 'diamonds-theme' ),
        'menu_name'          => _x( 'Diamonds', 'admin menu', 'diamonds-theme' ),
        'name_admin_bar'     => _x( 'Diamond', 'add new on admin bar', 'diamonds-theme' ),
        'add_new'            => _x( 'Add New', 'diamond', 'diamonds-theme' ),
        'add_new_item'       => __( 'Add New Diamond', 'diamonds-theme' ),
        'new_item'           => __( 'New Diamond', 'diamonds-theme' ),
        'edit_item'          => __( 'Edit Diamond', 'diamonds-theme' ),
        'view_item'          => __( 'View Diamond', 'diamonds-theme' ),
        'all_items'          => __( 'All Diamonds', 'diamonds-theme' ),
        'search_items'       => __( 'Search Diamonds', 'diamonds-theme' ),
        'parent_item_colon'  => __( 'Parent Diamonds:', 'diamonds-theme' ),
        'not_found'          => __( 'No diamonds found.', 'diamonds-theme' ),
        'not_found_in_trash' => __( 'No diamonds found in Trash.', 'diamonds-theme' )
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'diamond' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 20,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'show_in_rest'       => true,
    );

    register_post_type( 'diamond', $args );
}
add_action( 'init', 'diamonds_register_cpt' );

/**
 * Register custom taxonomies for Diamonds.
 *
 * We register the following non-hierarchical taxonomies: shape, cut, color, clarity, lab.
 */
function diamonds_register_taxonomies() {
    $taxonomies = array(
        'shape'   => __( 'Shape', 'diamonds-theme' ),
        'cut'     => __( 'Cut', 'diamonds-theme' ),
        'color'   => __( 'Color', 'diamonds-theme' ),
        'clarity' => __( 'Clarity', 'diamonds-theme' ),
        'lab'     => __( 'Lab', 'diamonds-theme' ),
    );

    foreach ( $taxonomies as $taxonomy => $label ) {
        $args = array(
            'labels'            => array(
                'name'              => $label,
                'singular_name'     => $label,
                'search_items'      => sprintf( __( 'Search %s', 'diamonds-theme' ), $label ),
                'all_items'         => sprintf( __( 'All %s', 'diamonds-theme' ), $label ),
                'edit_item'         => sprintf( __( 'Edit %s', 'diamonds-theme' ), $label ),
                'update_item'       => sprintf( __( 'Update %s', 'diamonds-theme' ), $label ),
                'add_new_item'      => sprintf( __( 'Add New %s', 'diamonds-theme' ), $label ),
                'new_item_name'     => sprintf( __( 'New %s Name', 'diamonds-theme' ), $label ),
                'menu_name'         => $label,
            ),
            'hierarchical'      => false,
            'public'            => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'show_in_rest'      => true,
            'rewrite'           => array( 'slug' => $taxonomy ),
        );
        register_taxonomy( $taxonomy, array( 'diamond' ), $args );
    }
}
add_action( 'init', 'diamonds_register_taxonomies' );

/**
 * Register meta fields for the diamond post type.
 *
 * We expose these via the REST API so that JavaScript applications can read them.
 */
function diamonds_register_meta() {
    $meta_keys = array(
        '_dd_carat'           => 'float',
        '_dd_price'           => 'float',
        '_dd_price_per_carat' => 'float',
        '_dd_vendor'          => 'string',
        '_dd_affiliate_url'   => 'string',
    );
    foreach ( $meta_keys as $meta_key => $type ) {
        register_post_meta(
            'diamond',
            $meta_key,
            array(
                'show_in_rest'      => true,
                'single'            => true,
                'type'              => $type,
                'sanitize_callback' => ( 'float' === $type ) ? 'floatval' : 'sanitize_text_field',
                'auth_callback'     => function() {
                    return current_user_can( 'edit_posts' );
                },
            )
        );
    }
}
add_action( 'init', 'diamonds_register_meta' );

/**
 * Output the diamond search form via shortcode.
 *
 * Generates a mobile-first form with taxonomy selects and numeric range inputs
 * for carat and price. Results are rendered into a container that is updated
 * via AJAX by the associated JavaScript.
 *
 * @return string
 */
function diamonds_search_shortcode( $atts = array() ) {
    ob_start();
    ?>
    <div class="diamond-search">
        <form id="diamond-search-form">
            <select name="shape">
                <option value=""><?php esc_html_e( 'Shape', 'diamonds-theme' ); ?></option>
                <?php foreach ( get_terms( array( 'taxonomy' => 'shape', 'hide_empty' => false ) ) as $term ) : ?>
                    <option value="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="cut">
                <option value=""><?php esc_html_e( 'Cut', 'diamonds-theme' ); ?></option>
                <?php foreach ( get_terms( array( 'taxonomy' => 'cut', 'hide_empty' => false ) ) as $term ) : ?>
                    <option value="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="color">
                <option value=""><?php esc_html_e( 'Color', 'diamonds-theme' ); ?></option>
                <?php foreach ( get_terms( array( 'taxonomy' => 'color', 'hide_empty' => false ) ) as $term ) : ?>
                    <option value="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="clarity">
                <option value=""><?php esc_html_e( 'Clarity', 'diamonds-theme' ); ?></option>
                <?php foreach ( get_terms( array( 'taxonomy' => 'clarity', 'hide_empty' => false ) ) as $term ) : ?>
                    <option value="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></option>
                <?php endforeach; ?>
            </select>
            <select name="lab">
                <option value=""><?php esc_html_e( 'Lab', 'diamonds-theme' ); ?></option>
                <?php foreach ( get_terms( array( 'taxonomy' => 'lab', 'hide_empty' => false ) ) as $term ) : ?>
                    <option value="<?php echo esc_attr( $term->slug ); ?>"><?php echo esc_html( $term->name ); ?></option>
                <?php endforeach; ?>
            </select>
            <input type="number" name="min_carat" step="0.01" placeholder="<?php echo esc_attr__( 'Min Carat', 'diamonds-theme' ); ?>">
            <input type="number" name="max_carat" step="0.01" placeholder="<?php echo esc_attr__( 'Max Carat', 'diamonds-theme' ); ?>">
            <input type="number" name="min_price" step="1" placeholder="<?php echo esc_attr__( 'Min Price', 'diamonds-theme' ); ?>">
            <input type="number" name="max_price" step="1" placeholder="<?php echo esc_attr__( 'Max Price', 'diamonds-theme' ); ?>">
            <button type="submit" class="button"><?php esc_html_e( 'Search', 'diamonds-theme' ); ?></button>
        </form>
        <div id="diamond-results"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'diamond_search', 'diamonds_search_shortcode' );

/**
 * AJAX handler for the diamond search.
 *
 * Processes posted filters and returns a JSON payload with matching diamonds. For brevity,
 * this implementation does not support all features described in the specification (e.g. sorting by price per carat asc/desc).
 */
function diamonds_search_ajax() {
    // Set up default query args.
    $args = array(
        'post_type'      => 'diamond',
        'post_status'    => 'publish',
        'posts_per_page' => 12,
    );

    // Allow both GET and POST parameters.
    $request = wp_unslash( $_REQUEST );

    // Taxonomy filters: shape, cut, color, clarity, lab.
    $tax_filters = array();
    $taxonomies  = array( 'shape', 'cut', 'color', 'clarity', 'lab' );
    foreach ( $taxonomies as $tax ) {
        if ( ! empty( $request[ $tax ] ) ) {
            $tax_filters[] = array(
                'taxonomy' => $tax,
                'field'    => 'slug',
                'terms'    => (array) $request[ $tax ],
            );
        }
    }
    if ( ! empty( $tax_filters ) ) {
        $args['tax_query'] = array_merge( array( 'relation' => 'AND' ), $tax_filters );
    }

    // Meta range queries for carat and price.
    $meta_query = array();
    if ( isset( $request['min_carat'] ) || isset( $request['max_carat'] ) ) {
        $min = isset( $request['min_carat'] ) ? floatval( $request['min_carat'] ) : 0;
        $max = isset( $request['max_carat'] ) ? floatval( $request['max_carat'] ) : 1000;
        $meta_query[] = array(
            'key'     => '_dd_carat',
            'value'   => array( $min, $max ),
            'type'    => 'numeric',
            'compare' => 'BETWEEN',
        );
    }
    if ( isset( $request['min_price'] ) || isset( $request['max_price'] ) ) {
        $min = isset( $request['min_price'] ) ? floatval( $request['min_price'] ) : 0;
        $max = isset( $request['max_price'] ) ? floatval( $request['max_price'] ) : 1000000;
        $meta_query[] = array(
            'key'     => '_dd_price',
            'value'   => array( $min, $max ),
            'type'    => 'numeric',
            'compare' => 'BETWEEN',
        );
    }
    if ( ! empty( $meta_query ) ) {
        $args['meta_query'] = $meta_query;
    }

    // Query diamonds and output HTML.
    $diamonds = new WP_Query( $args );
    if ( $diamonds->have_posts() ) {
        while ( $diamonds->have_posts() ) {
            $diamonds->the_post();
            echo diamonds_get_card( get_the_ID() );
        }
        wp_reset_postdata();
    } else {
        echo '<p>' . esc_html__( 'No diamonds found.', 'diamonds-theme' ) . '</p>';
    }

    wp_die();
}
add_action( 'wp_ajax_diamonds_search', 'diamonds_search_ajax' );
add_action( 'wp_ajax_nopriv_diamonds_search', 'diamonds_search_ajax' );

/**
 * Register a custom post type for Vendors.
 *
 * Vendors represent diamond retailers and are used on the reviews and comparisons
 * section of the site. Each vendor supports ratings, pros/cons lists, key
 * features and a partner flag. Vendors are public and queryable and can be
 * managed from the WordPress dashboard.
 */
function diamonds_register_vendor_cpt() {
    $labels = array(
        'name'               => _x( 'Vendors', 'post type general name', 'diamonds-theme' ),
        'singular_name'      => _x( 'Vendor', 'post type singular name', 'diamonds-theme' ),
        'menu_name'          => _x( 'Vendors', 'admin menu', 'diamonds-theme' ),
        'name_admin_bar'     => _x( 'Vendor', 'add new on admin bar', 'diamonds-theme' ),
        'add_new'            => _x( 'Add New', 'vendor', 'diamonds-theme' ),
        'add_new_item'       => __( 'Add New Vendor', 'diamonds-theme' ),
        'new_item'           => __( 'New Vendor', 'diamonds-theme' ),
        'edit_item'          => __( 'Edit Vendor', 'diamonds-theme' ),
        'view_item'          => __( 'View Vendor', 'diamonds-theme' ),
        'all_items'          => __( 'All Vendors', 'diamonds-theme' ),
        'search_items'       => __( 'Search Vendors', 'diamonds-theme' ),
        'parent_item_colon'  => __( 'Parent Vendors:', 'diamonds-theme' ),
        'not_found'          => __( 'No vendors found.', 'diamonds-theme' ),
        'not_found_in_trash' => __( 'No vendors found in Trash.', 'diamonds-theme' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'vendor' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 21,
        'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'show_in_rest'       => true,
    );

    register_post_type( 'vendor', $args );
}
add_action( 'init', 'diamonds_register_vendor_cpt' );

/**
 * Register a taxonomy for vendor key features.
 *
 * The vendor_feature taxonomy allows categorisation of vendors by the services
 * and benefits they provide (e.g. free shipping, 30‑day returns). It is
 * non‑hierarchical so behaves like tags.
 */
function diamonds_register_vendor_taxonomy() {
    $labels = array(
        'name'                       => _x( 'Vendor Features', 'taxonomy general name', 'diamonds-theme' ),
        'singular_name'              => _x( 'Vendor Feature', 'taxonomy singular name', 'diamonds-theme' ),
        'search_items'               => __( 'Search Vendor Features', 'diamonds-theme' ),
        'popular_items'              => __( 'Popular Vendor Features', 'diamonds-theme' ),
        'all_items'                  => __( 'All Vendor Features', 'diamonds-theme' ),
        'edit_item'                  => __( 'Edit Vendor Feature', 'diamonds-theme' ),
        'update_item'                => __( 'Update Vendor Feature', 'diamonds-theme' ),
        'add_new_item'               => __( 'Add New Vendor Feature', 'diamonds-theme' ),
        'new_item_name'              => __( 'New Vendor Feature Name', 'diamonds-theme' ),
        'separate_items_with_commas' => __( 'Separate vendor features with commas', 'diamonds-theme' ),
        'add_or_remove_items'        => __( 'Add or remove vendor features', 'diamonds-theme' ),
        'choose_from_most_used'      => __( 'Choose from the most used vendor features', 'diamonds-theme' ),
        'not_found'                  => __( 'No vendor features found.', 'diamonds-theme' ),
        'menu_name'                  => __( 'Vendor Features', 'diamonds-theme' ),
    );

    $args = array(
        'hierarchical'          => false,
        'labels'                => $labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'vendor-feature' ),
        'show_in_rest'          => true,
    );

    register_taxonomy( 'vendor_feature', 'vendor', $args );
}
add_action( 'init', 'diamonds_register_vendor_taxonomy' );

/**
 * Register meta fields for vendors.
 *
 * Vendors use a set of rating fields and supporting metadata. All meta is
 * exposed via the REST API for possible headless implementations.
 */
function diamonds_register_vendor_meta() {
    $meta_fields = array(
        '_vd_rating'   => 'float', // overall rating, 0–5
        '_vd_reviews'  => 'integer', // number of reviews
        '_vd_pricing'  => 'float', // pricing rating
        '_vd_selection'=> 'float', // selection rating
        '_vd_service'  => 'float', // customer service rating
        '_vd_shipping' => 'float', // shipping rating
        '_vd_quality'  => 'float', // product quality rating
        '_vd_pros'     => 'string', // comma separated list of pros
        '_vd_cons'     => 'string', // comma separated list of cons
        '_vd_url'      => 'string', // external URL for visit site button
        '_vd_partner'  => 'boolean', // whether vendor is a partner
    );
    foreach ( $meta_fields as $key => $type ) {
        register_post_meta( 'vendor', $key, array(
            'type'              => $type,
            'single'            => true,
            'show_in_rest'      => true,
            'sanitize_callback' => function( $value ) use ( $type ) {
                switch ( $type ) {
                    case 'float':
                        return floatval( $value );
                    case 'integer':
                        return intval( $value );
                    case 'boolean':
                        return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
                    default:
                        return sanitize_text_field( $value );
                }
            },
            'auth_callback'     => function() {
                return current_user_can( 'edit_posts' );
            },
        ) );
    }
}
add_action( 'init', 'diamonds_register_vendor_meta' );

/**
 * Render a vendor card for archive listings.
 *
 * This helper echoes markup similar to the vendor blocks on the reference site. It
 * displays the vendor logo/initial, name, rating stars, review count,
 * excerpt, a short pros/cons list and a Visit button. For brevity the
 * rating breakdown bars and sample review have been omitted. Developers can
 * extend this function or create a single-vendor template for more detail.
 *
 * @param int $post_id Vendor post ID.
 * @return string HTML markup for the card.
 */
function diamonds_get_vendor_card( $post_id ) {
    $title     = get_the_title( $post_id );
    $link      = get_permalink( $post_id );
    $excerpt   = get_the_excerpt( $post_id );
    $rating    = floatval( get_post_meta( $post_id, '_vd_rating', true ) );
    $reviews   = intval( get_post_meta( $post_id, '_vd_reviews', true ) );
    $pros      = array_filter( array_map( 'trim', explode( ',', get_post_meta( $post_id, '_vd_pros', true ) ) ) );
    $cons      = array_filter( array_map( 'trim', explode( ',', get_post_meta( $post_id, '_vd_cons', true ) ) ) );
    $features  = get_the_terms( $post_id, 'vendor_feature' );
    $url       = esc_url( get_post_meta( $post_id, '_vd_url', true ) );
    $partner   = filter_var( get_post_meta( $post_id, '_vd_partner', true ), FILTER_VALIDATE_BOOLEAN );
    ob_start();
    ?>
    <article class="vendor-card">
        <header class="vendor-card-header">
            <div class="vendor-avatar">
                <?php if ( has_post_thumbnail( $post_id ) ) : ?>
                    <?php echo get_the_post_thumbnail( $post_id, 'thumbnail' ); ?>
                <?php else : ?>
                    <span class="vendor-initial"><?php echo esc_html( strtoupper( mb_substr( $title, 0, 1 ) ) ); ?></span>
                <?php endif; ?>
            </div>
            <div class="vendor-title-area">
                <h3 class="vendor-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></h3>
                <?php if ( $partner ) : ?>
                    <span class="vendor-partner-badge"><?php esc_html_e( 'Partner', 'diamonds-theme' ); ?></span>
                <?php endif; ?>
                <div class="vendor-rating">
                    <span class="rating-stars" aria-hidden="true">
                        <?php
                        // Output star icons based on rating (up to 5). Use Unicode stars for simplicity.
                        $full_stars = floor( $rating );
                        $half_star  = ( $rating - $full_stars ) >= 0.5;
                        for ( $i = 0; $i < 5; $i++ ) {
                            if ( $i < $full_stars ) {
                                echo '★';
                            } elseif ( $i === $full_stars && $half_star ) {
                                echo '☆';
                                $half_star = false;
                            } else {
                                echo '☆';
                            }
                        }
                        ?>
                    </span>
                    <span class="vendor-rating-value"><?php echo esc_html( number_format_i18n( $rating, 1 ) ); ?></span>
                    <?php if ( $reviews ) : ?>
                        <span class="vendor-review-count">(<?php echo esc_html( number_format_i18n( $reviews ) ); ?> <?php esc_html_e( 'reviews', 'diamonds-theme' ); ?>)</span>
                    <?php endif; ?>
                </div>
            </div>
        </header>
        <div class="vendor-excerpt">
            <?php echo wp_kses_post( wp_trim_words( $excerpt, 30 ) ); ?>
        </div>
        <?php if ( ! empty( $pros ) || ! empty( $cons ) ) : ?>
            <div class="vendor-pros-cons">
                <?php if ( ! empty( $pros ) ) : ?>
                    <div class="vendor-pros">
                        <strong><?php esc_html_e( 'Pros', 'diamonds-theme' ); ?>:</strong>
                        <ul>
                            <?php foreach ( $pros as $pro ) : ?>
                                <li><?php echo esc_html( $pro ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if ( ! empty( $cons ) ) : ?>
                    <div class="vendor-cons">
                        <strong><?php esc_html_e( 'Cons', 'diamonds-theme' ); ?>:</strong>
                        <ul>
                            <?php foreach ( $cons as $con ) : ?>
                                <li><?php echo esc_html( $con ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if ( $features && ! is_wp_error( $features ) ) : ?>
            <div class="vendor-features">
                <?php foreach ( $features as $feature ) : ?>
                    <span class="vendor-feature-tag"><?php echo esc_html( $feature->name ); ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <div class="vendor-actions">
            <?php if ( $url ) : ?>
                <a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="nofollow sponsored" class="button vendor-visit-button">
                    <?php printf( esc_html__( 'Visit %s', 'diamonds-theme' ), esc_html( $title ) ); ?>
                </a>
            <?php endif; ?>
            <a href="<?php echo esc_url( $link ); ?>" class="button vendor-more-button">
                <?php esc_html_e( 'Full Review', 'diamonds-theme' ); ?>
            </a>
        </div>
    </article>
    <?php
    return ob_get_clean();
}

/**
 * Render a table row for vendor comparison.
 *
 * Outputs a row containing vendor name, overall rating, review count and star
 * ratings for pricing, selection and service. Columns can be extended as
 * needed. This helper is used in the archive template.
 *
 * @param int $post_id Vendor post ID.
 * @return string HTML table row.
 */
function diamonds_get_vendor_table_row( $post_id ) {
    $title    = get_the_title( $post_id );
    $link     = get_post_meta( $post_id, '_vd_url', true ) ?: get_permalink( $post_id );
    $rating   = floatval( get_post_meta( $post_id, '_vd_rating', true ) );
    $reviews  = intval( get_post_meta( $post_id, '_vd_reviews', true ) );
    $pricing  = floatval( get_post_meta( $post_id, '_vd_pricing', true ) );
    $selection= floatval( get_post_meta( $post_id, '_vd_selection', true ) );
    $service  = floatval( get_post_meta( $post_id, '_vd_service', true ) );
    ob_start();
    ?>
    <tr class="vendor-row">
        <td class="vendor-name"><a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="nofollow sponsored"><?php echo esc_html( $title ); ?></a></td>
        <td class="vendor-rating">
            <?php echo esc_html( number_format_i18n( $rating, 1 ) ); ?>
        </td>
        <td class="vendor-reviews">
            <?php echo esc_html( number_format_i18n( $reviews ) ); ?>
        </td>
        <td class="vendor-pricing">
            <?php echo esc_html( number_format_i18n( $pricing, 1 ) ); ?>
        </td>
        <td class="vendor-selection">
            <?php echo esc_html( number_format_i18n( $selection, 1 ) ); ?>
        </td>
        <td class="vendor-service">
            <?php echo esc_html( number_format_i18n( $service, 1 ) ); ?>
        </td>
        <td class="vendor-action">
            <a href="<?php echo esc_url( $link ); ?>" target="_blank" rel="nofollow sponsored" class="button vendor-visit-table">
                <?php esc_html_e( 'Visit Site', 'diamonds-theme' ); ?>
            </a>
        </td>
    </tr>
    <?php
    return ob_get_clean();
}

/**
 * Register a custom post type for customer reviews.
 *
 * These posts represent individual customer reviews used in the recent reviews
 * section. They can be imported programmatically from external services. Each
 * review references a vendor via post meta.
 */
function diamonds_register_review_cpt() {
    $labels = array(
        'name'               => _x( 'Customer Reviews', 'post type general name', 'diamonds-theme' ),
        'singular_name'      => _x( 'Customer Review', 'post type singular name', 'diamonds-theme' ),
        'menu_name'          => _x( 'Reviews', 'admin menu', 'diamonds-theme' ),
        'name_admin_bar'     => _x( 'Review', 'add new on admin bar', 'diamonds-theme' ),
        'add_new'            => _x( 'Add New', 'review', 'diamonds-theme' ),
        'add_new_item'       => __( 'Add New Review', 'diamonds-theme' ),
        'new_item'           => __( 'New Review', 'diamonds-theme' ),
        'edit_item'          => __( 'Edit Review', 'diamonds-theme' ),
        'view_item'          => __( 'View Review', 'diamonds-theme' ),
        'all_items'          => __( 'All Reviews', 'diamonds-theme' ),
        'search_items'       => __( 'Search Reviews', 'diamonds-theme' ),
        'not_found'          => __( 'No reviews found.', 'diamonds-theme' ),
        'not_found_in_trash' => __( 'No reviews found in Trash.', 'diamonds-theme' ),
    );
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'review' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 22,
        'supports'           => array( 'title', 'editor', 'excerpt' ),
        'show_in_rest'       => true,
    );
    register_post_type( 'review', $args );
}
add_action( 'init', 'diamonds_register_review_cpt' );

/**
 * Register meta fields for customer reviews.
 *
 * Meta fields include rating (1–5), vendor ID and verification status. All
 * fields are exposed via REST for programmatic import and front‑end use.
 */
function diamonds_register_review_meta() {
    $review_meta = array(
        '_rv_rating'   => 'integer',
        '_rv_vendor'   => 'integer',
        '_rv_verified' => 'boolean',
    );
    foreach ( $review_meta as $key => $type ) {
        register_post_meta( 'review', $key, array(
            'type'              => $type,
            'single'            => true,
            'show_in_rest'      => true,
            'sanitize_callback' => function( $value ) use ( $type ) {
                switch ( $type ) {
                    case 'integer':
                        return intval( $value );
                    case 'boolean':
                        return filter_var( $value, FILTER_VALIDATE_BOOLEAN );
                    default:
                        return sanitize_text_field( $value );
                }
            },
            'auth_callback'     => function() {
                return current_user_can( 'edit_posts' );
            },
        ) );
    }
}
add_action( 'init', 'diamonds_register_review_meta' );

/**
 * Render a grid of recent customer reviews.
 *
 * Retrieves recent review posts and outputs small cards similar to the
 * reference site. Each card shows the star rating, verification badge,
 * excerpt, reviewer and date. Only published reviews are shown.
 *
 * @param int $count Number of reviews to display.
 * @return string HTML markup for the reviews grid.
 */
function diamonds_get_recent_reviews( $count = 6 ) {
    $args = array(
        'post_type'      => 'review',
        'post_status'    => 'publish',
        'posts_per_page' => $count,
        'orderby'        => 'date',
        'order'          => 'DESC',
    );
    $reviews = new WP_Query( $args );
    if ( ! $reviews->have_posts() ) {
        return '';
    }
    ob_start();
    ?>
    <div class="recent-reviews-grid">
        <?php while ( $reviews->have_posts() ) : $reviews->the_post();
            $rating   = intval( get_post_meta( get_the_ID(), '_rv_rating', true ) );
            $vendor_id= intval( get_post_meta( get_the_ID(), '_rv_vendor', true ) );
            $vendor   = $vendor_id ? get_the_title( $vendor_id ) : '';
            $verified = filter_var( get_post_meta( get_the_ID(), '_rv_verified', true ), FILTER_VALIDATE_BOOLEAN );
            ?>
            <div class="review-card">
                <div class="review-rating">
                    <?php for ( $i = 0; $i < 5; $i++ ) {
                        echo ( $i < $rating ) ? '★' : '☆';
                    } ?>
                    <?php if ( $verified ) : ?><span class="review-verified"><?php esc_html_e( 'Verified', 'diamonds-theme' ); ?></span><?php endif; ?>
                    <span class="review-date"><?php echo esc_html( human_time_diff( get_the_date( 'U' ), current_time( 'timestamp' ) ) ); ?> <?php esc_html_e( 'ago', 'diamonds-theme' ); ?></span>
                </div>
                <div class="review-body">
                    <?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 25 ) ); ?>
                </div>
                <div class="review-footer">
                    <span class="review-author"><?php echo esc_html( get_the_author() ); ?></span>
                    <?php if ( $vendor ) : ?>
                        <span class="review-vendor"><?php echo esc_html( $vendor ); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
    <?php
    wp_reset_postdata();
    return ob_get_clean();
}

/**
 * Helper function to render a diamond card.
 *
 * @param int $post_id The post ID of the diamond.
 * @return string HTML markup for the diamond card.
 */
function diamonds_get_card( $post_id ) {
    $link   = get_permalink( $post_id );
    $title  = get_the_title( $post_id );
    $price  = get_post_meta( $post_id, '_dd_price', true );
    $carat  = get_post_meta( $post_id, '_dd_carat', true );
    $vendor = get_post_meta( $post_id, '_dd_vendor', true );
    $thumb  = get_the_post_thumbnail_url( $post_id, 'medium' );
    ob_start();
    ?>
    <article class="diamond-card">
        <?php if ( $thumb ) : ?>
            <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr( $title ); ?>">
        <?php endif; ?>
        <div class="card-content">
            <h3><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></h3>
            <?php if ( $price !== '' ) : ?>
                <p class="price"><?php echo esc_html( number_format_i18n( $price, 2 ) ); ?></p>
            <?php endif; ?>
            <p class="meta"><?php echo esc_html( $carat ); ?>ct<?php if ( $vendor ) echo ' · ' . esc_html( $vendor ); ?></p>
            <a href="<?php echo esc_url( $link ); ?>" class="button"><?php esc_html_e( 'View', 'diamonds-theme' ); ?></a>
        </div>
    </article>
    <?php
    return ob_get_clean();
}
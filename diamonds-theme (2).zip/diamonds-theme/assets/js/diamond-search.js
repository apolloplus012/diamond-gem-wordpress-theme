/**
 * AJAX-powered search for Diamond custom post type.
 *
 * This script collects filter values from the search form and requests
 * filtered results from the server via admin-ajax.php. Results are returned
 * as HTML and injected into the results container. It also triggers a search
 * whenever the user adjusts a filter or submits the form.
 */

(function ($) {
    /**
     * Perform the AJAX search.
     */
    function performSearch() {
        var $form = $('#diamond-search-form');
        var data = $form.serializeArray();
        // Add the action so WordPress knows which callback to run.
        data.push({ name: 'action', value: 'diamonds_search' });

        // Determine the AJAX endpoint. The PHP side localizes `diamondsSearch.ajaxUrl`,
        // but fall back to the default admin-ajax path if it isn't defined.
        var ajaxUrl =
            typeof diamondsSearch !== 'undefined' && diamondsSearch.ajaxUrl
                ? diamondsSearch.ajaxUrl
                : '/wp-admin/admin-ajax.php';

        // Indicate loading state.
        $('#diamond-results').addClass('loading');

        // Send the request and replace results.
        $.get(ajaxUrl, $.param(data), function (response) {
            $('#diamond-results').html(response);
            $('#diamond-results').removeClass('loading');
        });
    }

    // Bind form submit.
    $(document).on('submit', '#diamond-search-form', function (e) {
        e.preventDefault();
        performSearch();
    });

    // Auto-submit when filters change.
    $(document).on(
        'change',
        '#diamond-search-form select, #diamond-search-form input',
        function () {
            performSearch();
        }
    );

    // Optionally trigger an initial search on page load.
    $(document).ready(function () {
        if ($('#diamond-search-form').length) {
            performSearch();
        }
    });
})(jQuery);
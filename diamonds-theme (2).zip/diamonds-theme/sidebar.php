<?php
/**
 * Sidebar template for Diamonds Theme.
 *
 * This template is included in the main layout but kept empty by default.
 * You can add widgets via the WordPress widgets panel or create your own
 * sidebar content here.
 *
 * @package Diamonds Theme
 */

if ( is_active_sidebar( 'sidebar-1' ) ) :
    ?>
    <aside id="secondary" class="widget-area">
        <?php dynamic_sidebar( 'sidebar-1' ); ?>
    </aside>
    <?php
endif;
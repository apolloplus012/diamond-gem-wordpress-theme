<?php
/**
 * Template part for displaying a message that posts cannot be found.
 *
 * Used both on the front page and on archive pages.
 *
 * @package Diamonds Theme
 */
?>
<section class="no-results not-found">
    <header class="page-header">
        <h1 class="page-title"><?php _e( 'Nothing Found', 'diamonds-theme' ); ?></h1>
    </header><!-- .page-header -->

    <div class="page-content">
        <p><?php _e( 'It seems we can’t find what you’re looking for. Perhaps searching can help.', 'diamonds-theme' ); ?></p>
        <?php get_search_form(); ?>
    </div><!-- .page-content -->
</section><!-- .no-results -->